# Hybrid Healing Quickstart

This quickstart gets you from zero to first successful Hybrid (Layer 5) healing fast.

## 1) Prerequisites
- Java 11+
- Maven 3.8+
- Chrome installed
- Neo4j running locally (Bolt enabled)

## 2) Start Neo4j

### Option A: Native Windows Neo4j
From your Neo4j installation directory:
```powershell
bin\neo4j.bat console
```

### Option B: Docker
```powershell
docker run -d --name neo4j-local -p 7474:7474 -p 7687:7687 -e NEO4J_AUTH=neo4j/password neo4j:5
```

Verify Neo4j UI:
- [http://localhost:7474](http://localhost:7474)

## 3) Configure Hybrid Properties
Update `src/main/resources/healing-config.properties`:

```properties
healing.enabled=true

healing.layer1.enabled=true
healing.layer2.enabled=true
healing.layer3.enabled=true
healing.layer4.enabled=true
healing.hybrid.enabled=true

healing.hybrid.neo4j.uri=bolt://localhost:7687
healing.hybrid.neo4j.user=neo4j
healing.hybrid.neo4j.password=password

healing.hybrid.vector.jdbc.url=jdbc:h2:mem:healing_vectors;DB_CLOSE_DELAY=-1
healing.hybrid.vector.jdbc.user=sa
healing.hybrid.vector.jdbc.password=
```

## 4) Compile (Java 11 target)
```powershell
mvn -q -DskipTests "-Dmaven.compiler.release=11" compile
```

## 5) Run Focused Hybrid Unit Tests
```powershell
mvn -q "-Dtest=HybridHealingEngineTest,TemporalTrustServiceTest,DomDnaNormalizerTest" "-Dsurefire.suiteXmlFiles=" test
```

## 6) Optional: Bootstrap Knowledge Before Demo

Compile classpath:
```powershell
mvn -q -DskipTests test-compile dependency:build-classpath "-Dmdep.outputFile=target/classpath.txt"
```

Train from runtime page source:
```powershell
$cp = Get-Content "target/classpath.txt"
java -cp "target/test-classes;target/classes;$cp" com.healing.intelligence.tools.KnowledgeBootstrapUtility --mode=runtime --url=https://the-internet.herokuapp.com/login --page=https://the-internet.herokuapp.com/login --testCase=bootstrap-runtime --build=boot-1
```

## 7) Run End-to-End Demo (Self-Healing)
```powershell
$cp = Get-Content "target/classpath.txt"
java -cp "target/test-classes;target/classes;$cp" org.testng.TestNG -testclass com.healing.tests.SelfHealingDemoTest
```

Expected:
- Demo tests execute (not skipped)
- healing reports generated in `target/healing-reports`

## 8) Validate Layer 5 in Isolation (Optional)
Set:
```properties
healing.layer1.enabled=false
healing.layer2.enabled=false
healing.layer3.enabled=false
healing.layer4.enabled=false
healing.hybrid.enabled=true
```

Re-run demo command from step 7.

## 9) Output Artifacts
- HTML report: `target/healing-reports/healing-dashboard-<timestamp>.html`
- JSON report: `target/healing-reports/healing-report-<timestamp>.json`

## 10) If Something Fails Quickly Check
- Neo4j URI is valid (`bolt://...`, not username/password text)
- Neo4j credentials are correct
- ChromeDriver version resolves via WebDriverManager
- For TestNG in this repo, use direct `org.testng.TestNG` command if Maven runs 0 tests
