# Hybrid Intelligence Complete Reference

This document is the full technical reference and handover for engineering teams integrating the framework in another Selenium + Java project.

## 1) System Architecture

### 1.1 Functional Intent
The framework handles locator failures by combining:
- graph-history intelligence (relationship memory)
- embedding intelligence (semantic proximity)
- adaptive runtime learning (success/failure feedback loop)

### 1.2 End-to-End Sequence
1. Selenium lookup fails in `SelfHealingWebDriver`.
2. `HybridHealingCoordinator` activates and runs configured layers.
3. Layer 5 (`HybridIntelligenceHealingLayer`) asks `HybridHealingEngine` for ranked candidates.
4. Engine combines graph candidates + vector candidates + bootstrap candidates.
5. Layer retries candidates in ranked order.
6. On success:
   - graph updated (`HEALED_TO`, trust, counters)
   - vector embedding upserted
7. On failure:
   - graph failure tracked (`FAILED_IN`)
   - trust decay applied

## 2) Code Map (What File Does What)

### 2.1 Core Runtime
- `com.healing.core.SelfHealingWebDriver`
  - intercepts `findElement`/`findElements`
  - exposes `findElementSmart(locatorId)`
- `com.healing.core.HybridHealingCoordinator`
  - orchestrates all healing layers
  - records result + reporting

### 2.2 Layer 5 Runtime
- `com.healing.layers.HybridIntelligenceHealingLayer`
  - invokes hybrid engine
  - retries top candidates
  - records success/failure in `HealingResult`

### 2.3 Hybrid Domain Model
- `DomDna`: normalized DOM context payload
- `LocatorCandidate`: candidate + score parts
- `HistoricalStats`: success/failure/trust record
- `HealingSignal`: writeback payload for success

### 2.4 Ports (Contracts)
- `GraphService`
- `EmbeddingService`
- `VectorSearchService`
- `HealingEngine`

These isolate implementation details and enable swapping backends.

### 2.5 Application Layer
- `HybridHealingEngine`
  - candidate collection, merge, scoring
  - bootstrap candidate generation
  - writeback learning calls
- `HybridScoringService`
  - weighted score formula
- `TemporalTrustService`
  - temporal/build-aware score adjustment

### 2.6 Infrastructure Layer
- `Neo4jGraphService`
  - schema bootstrap
  - graph candidate retrieval
  - success/failure writeback
  - trust decay
  - bootstrap upsert API (`upsertLocatorKnowledge`)
- `H2VectorSearchService`
  - vector table bootstrap
  - top-K cosine retrieval
  - robust locator reconstruction fallback
- `CosineSimilarity`
  - numeric cosine utility
- `DomDnaNormalizer`
  - deterministic normalization and serialization
- `DjlEmbeddingService`
  - local embedding generation abstraction point

### 2.7 Wiring
- `HybridIntelligenceFactory`
  - builds Neo4j + embedding + vector services
  - returns configured `HybridHealingEngine`

### 2.8 Training Utility
- `com.healing.intelligence.tools.KnowledgeBootstrapUtility`
  - trains graph + vector from:
    - HTML file
    - locator JSON file
    - runtime page source from URL

## 3) Data Model Details

### 3.1 Neo4j Labels
- `Locator`
- `Page`
- `TestCase`
- `Build`

### 3.2 Neo4j Relationships
- `LOCATED_ON`
- `USED_IN`
- `FAILED_IN`
- `HEALED_TO`
- `SIMILAR_TO` (reserved/optional extension)

### 3.3 Neo4j Core Fields
- Locator fields: `id, css, xpath, text, page, createdAt, lastSeenAt, failCount, successCount, trustScore`
- Edge fields:
  - `HEALED_TO`: `confidence, timestamp, successCount, lastSuccessAt`
  - `FAILED_IN`: `timestamp, page, failureType`

### 3.4 H2 Vector Schema
Table: `locator_embeddings`
- `locator_id`
- `embedding_id`
- `page`
- `page_type`
- `css`
- `xpath`
- `dim`
- `vector_blob`
- `norm`
- `weight`
- `updated_at`

## 4) Scoring and Retrieval

### 4.1 Weighted Score
`final = 0.6*embedding + 0.3*graph + 0.1*historical`

### 4.2 Candidate Sources
- graph healed edges (`HEALED_TO`)
- same-page graph neighbors
- vector top-K retrieval
- runtime bootstrap candidates (id/name/testid/aria/css/xpath/tag-role)

### 4.3 Isolation Hardening Implemented
- bootstrap candidates injected before scoring
- vector row locator reconstruction fallback from locator id format
- css/xpath fallback persistence for `By.id` and `By.name`

## 5) Config Catalog

### 5.1 Global
- `healing.enabled`

### 5.2 Existing Layers
- `healing.layer1.enabled`
- `healing.layer2.enabled`
- `healing.layer3.enabled`
- `healing.layer4.enabled`

### 5.3 Hybrid Layer
- `healing.hybrid.enabled`
- `healing.hybrid.build.version`
- `healing.hybrid.retry.count`
- `healing.hybrid.vector.topk`
- `healing.hybrid.graph.threshold`
- `healing.hybrid.neo4j.uri`
- `healing.hybrid.neo4j.user`
- `healing.hybrid.neo4j.password`
- `healing.hybrid.embedding.model`
- `healing.hybrid.vector.jdbc.url`
- `healing.hybrid.vector.jdbc.user`
- `healing.hybrid.vector.jdbc.password`

## 6) Setup Guide (New Project Adoption)

### 6.1 Step 1 - Add Dependencies
- Selenium/TestNG stack
- Neo4j Java Driver
- H2
- Gson
- Jsoup
- logging deps

### 6.2 Step 2 - Add Package Modules
Copy the package map listed in section 2.

### 6.3 Step 3 - Wire Into Driver
- use `SelfHealingWebDriver.wrap(rawDriver)`
- ensure coordinator includes `HybridIntelligenceHealingLayer`

### 6.4 Step 4 - Configure Properties
Set all hybrid properties in your env/property source.

### 6.5 Step 5 - Start Neo4j
- local or remote instance
- confirm Bolt reachable and auth valid

### 6.6 Step 6 - Bootstrap Knowledge
Run `KnowledgeBootstrapUtility` from HTML/JSON/runtime URL.

### 6.7 Step 7 - Validate
- compile with Java 11 target
- run hybrid unit tests
- run demo/integration tests

## 7) Training Utility Reference

### 7.1 Modes
- `--mode=html --input=<file>`
- `--mode=json --input=<file>`
- `--mode=runtime --url=<url>`

### 7.2 Common Arguments
- `--page=...`
- `--testCase=...`
- `--build=...`

### 7.3 JSON Seed Format
Example fields:
- `locatorId`
- one of `id | name | css | xpath`
- optional `page, text, tag, attributes`

### 7.4 What It Writes
- Neo4j:
  - Locator node
  - Page/TestCase/Build associations
- H2 vector:
  - embedding rows with css/xpath and weights

## 8) Verification and Test Commands

### 8.1 Build
`mvn -q -DskipTests "-Dmaven.compiler.release=11" compile`

### 8.2 Hybrid unit tests
`mvn -q "-Dtest=HybridHealingEngineTest,TemporalTrustServiceTest,DomDnaNormalizerTest" "-Dsurefire.suiteXmlFiles=" test`

### 8.3 Demo suite
Direct TestNG command is preferred in this repo when Surefire provider auto-detection interferes.

## 9) Operational Guidance

### 9.1 KPIs
- hybrid success rate
- candidate retry count distribution
- latency per stage
- failure spike per build

### 9.2 Logs to Monitor
- candidate list and chosen candidate
- score component values
- graph/vector writeback success/failure

### 9.3 Rollout Pattern
1. all layers enabled
2. train baseline graph/vector
3. measure precision + latency
4. optionally test Layer 5 in isolation

## 10) Known Constraints
- H2 vector store is starter-friendly, not high-scale production storage.
- current embedding service is deterministic local abstraction; can be replaced with full DJL model loading.
- quality improves significantly after data bootstrap + runtime learning history.

## 11) Recommended Next Enhancements
1. async parallel graph/vector retrieval
2. bulk bootstrap from crawl snapshots
3. tenant keys (`projectId`, `env`) across graph/vector
4. metrics export (Prometheus/OpenTelemetry)
5. scheduled trust/embedding maintenance jobs
