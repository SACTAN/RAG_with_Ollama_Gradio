package com.healing.tests;

import com.healing.intelligence.domain.DomDna;
import com.healing.intelligence.infrastructure.embedding.DomDnaNormalizer;
import com.healing.models.ElementContext;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;

public class DomDnaNormalizerTest {
    @Test
    public void producesDeterministicEmbeddingInput() {
        DomDnaNormalizer normalizer = new DomDnaNormalizer();
        ElementContext context = new ElementContext(By.id("login-button"))
            .withTagName("Button")
            .withInnerText("  Sign   In ")
            .withPageUrl("https://acme.example/login")
            .withParentXPath("//div[@id='header_12345']")
            .withDomDepth(3);
        HashMap<String, String> attrs = new HashMap<>();
        attrs.put("id", "login_btn_99999");
        attrs.put("data-testid", "LOGIN_MAIN");
        context.withAttributes(attrs);
        DomDna domDna = normalizer.fromContext("id:login-button", context);
        String first = normalizer.normalizeForEmbedding(domDna);
        String second = normalizer.normalizeForEmbedding(domDna);
        Assert.assertEquals(first, second);
        Assert.assertTrue(first.contains("pageType=auth"));
    }
}
