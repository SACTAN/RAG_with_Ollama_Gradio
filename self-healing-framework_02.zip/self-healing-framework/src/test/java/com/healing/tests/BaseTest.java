package com.healing.tests;

import com.healing.core.SelfHealingWebDriver;
import com.healing.reporting.HealingReporter;
import com.healing.utils.DriverFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Abstract base class for all self-healing tests.
 *
 * Provides:
 *  - Automatic SelfHealingWebDriver creation per test class
 *  - Screenshot on failure
 *  - Healing report generation after suite
 *  - Clean teardown
 *
 * Usage:
 *   public class MyLoginTest extends BaseTest {
 *       @Test
 *       public void testLogin() {
 *           driver.get("https://myapp.com");
 *           driver.click(By.id("old-submit-btn"));  // auto-heals if ID changed!
 *       }
 *   }
 */
public abstract class BaseTest {

    protected static final Logger log = LoggerFactory.getLogger(BaseTest.class);
    protected SelfHealingWebDriver driver;
    private static final HealingReporter SHARED_REPORTER = new HealingReporter();

    @BeforeClass
    public void setUp() {
        log.info("=== Setting up test: {} ===", getClass().getSimpleName());
        driver = createDriver();
    }

    /**
     * Override to customize browser type or options.
     */
    protected SelfHealingWebDriver createDriver() {
        String browser = System.getProperty("browser", "chrome");
        boolean headless = Boolean.parseBoolean(System.getProperty("headless", "false"));

        switch (browser.toLowerCase()) {
            case "firefox": return DriverFactory.createFirefoxDriver(headless);
            case "edge":    return DriverFactory.createEdgeDriver();
            default:        return DriverFactory.createChromeDriver(headless);
        }
    }

    @AfterMethod
    public void captureScreenshotOnFailure(ITestResult result) {
        if (!result.isSuccess() && driver != null) {
            captureScreenshot(result.getName());
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            try {
                driver.quit();
                log.info("Driver closed for: {}", getClass().getSimpleName());
            } catch (Exception e) {
                log.warn("Error closing driver: {}", e.getMessage());
            }
        }
    }

    @AfterSuite
    public void generateHealingReport() {
        log.info("=== Generating Self-Healing Report ===");
        SHARED_REPORTER.generateReport();
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    protected void captureScreenshot(String testName) {
        try {
            byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String path = "target/healing-reports/screenshots/" + testName + "_" + ts + ".png";
            Files.createDirectories(Paths.get("target/healing-reports/screenshots/"));
            Files.write(Paths.get(path), screenshot);
            log.info("Screenshot saved: {}", path);
        } catch (Exception e) {
            log.warn("Failed to capture screenshot: {}", e.getMessage());
        }
    }

    protected void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
