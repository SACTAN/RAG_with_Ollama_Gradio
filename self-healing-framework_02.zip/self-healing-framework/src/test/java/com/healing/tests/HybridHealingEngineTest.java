package com.healing.tests;

import com.healing.intelligence.application.HybridHealingEngine;
import com.healing.intelligence.application.HybridScoringService;
import com.healing.intelligence.application.TemporalTrustService;
import com.healing.intelligence.domain.HistoricalStats;
import com.healing.intelligence.domain.LocatorCandidate;
import com.healing.intelligence.infrastructure.embedding.DomDnaNormalizer;
import com.healing.intelligence.ports.EmbeddingService;
import com.healing.intelligence.ports.GraphService;
import com.healing.intelligence.ports.VectorSearchService;
import com.healing.models.ElementContext;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class HybridHealingEngineTest {
    @Test
    public void ranksHybridCandidatesByFinalScore() {
        GraphService graph = new StubGraphService(Arrays.asList(
            new LocatorCandidate("graph-1", By.id("graph-1"), "graph", 0.0, 0.85, new HistoricalStats(10, 1, 0.9))
        ));
        EmbeddingService embedding = domDna -> new float[]{0.2f, 0.8f};
        VectorSearchService vector = new StubVectorService(Arrays.asList(
            new LocatorCandidate("vector-1", By.id("vector-1"), "vector", 0.95, 0.0, new HistoricalStats(5, 1, 0.75))
        ));

        HybridHealingEngine engine = new HybridHealingEngine(graph, embedding, vector, new DomDnaNormalizer(),
            new TemporalTrustService(), new HybridScoringService(), 0.9d, 10);
        ElementContext context = new ElementContext(By.id("old")).withPageUrl("https://acme.example/login");

        List<LocatorCandidate> ranked = engine.findBestCandidates("id:old", context, "1.2.3");
        Assert.assertFalse(ranked.isEmpty());
        Assert.assertEquals(ranked.get(0).getLocatorId(), "vector-1");
        Assert.assertTrue(ranked.get(0).getFinalScore() > 0.55d);
    }

    private static class StubGraphService implements GraphService {
        private final List<LocatorCandidate> entries;
        StubGraphService(List<LocatorCandidate> entries) { this.entries = entries; }
        public void bootstrapSchema() {}
        public List<LocatorCandidate> fetchHealedToCandidates(String locatorId, String page, int limit) { return entries; }
        public List<LocatorCandidate> fetchSamePageCandidates(String page, int limit) { return Collections.emptyList(); }
        public double failureSpikeScore(String page, String buildVersion) { return 0.1d; }
        public void recordSuccess(com.healing.intelligence.domain.HealingSignal signal) {}
        public void recordFailure(String locatorId, String page, String buildVersion, String failureType) {}
        public void decayLocatorTrust(String page, int staleDays) {}
    }

    private static class StubVectorService implements VectorSearchService {
        private final List<LocatorCandidate> entries;
        StubVectorService(List<LocatorCandidate> entries) { this.entries = entries; }
        public List<LocatorCandidate> searchTopK(float[] queryEmbedding, String page, String pageType, int k) { return entries; }
        public void upsertEmbedding(String locatorId, String page, String pageType, float[] embedding, double weight) {}
    }
}
