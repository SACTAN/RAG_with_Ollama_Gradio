package com.healing.tests;

import com.healing.intelligence.application.TemporalTrustService;
import com.healing.intelligence.domain.HistoricalStats;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TemporalTrustServiceTest {
    @Test
    public void spikePenaltyReducesHistoricalScore() {
        TemporalTrustService service = new TemporalTrustService();
        double stable = service.adjustedHistoricalScore(new HistoricalStats(20, 5, 0.9), 0.0d);
        double spiky = service.adjustedHistoricalScore(new HistoricalStats(20, 5, 0.9), 1.0d);
        Assert.assertTrue(stable > spiky);
    }
}
