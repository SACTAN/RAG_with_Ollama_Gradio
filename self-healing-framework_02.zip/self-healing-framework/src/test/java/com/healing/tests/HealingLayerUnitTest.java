package com.healing.tests;

import com.healing.layers.*;
import com.healing.models.ElementContext;
import com.healing.models.HealingResult;
import com.healing.utils.LCSAlgorithm;
import com.healing.utils.HealingCache;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Unit tests for each healing layer and utility.
 * No WebDriver / browser needed — pure logic testing.
 *
 * Run: mvn test -Dtest=HealingLayerUnitTest
 */
public class HealingLayerUnitTest {

    private LCSAlgorithm lcs;
    private HealingCache cache;

    @BeforeClass
    public void setUp() {
        lcs = new LCSAlgorithm();
        cache = HealingCache.getInstance(100);
        cache.clear();
    }

    // ── LCS Algorithm Tests ───────────────────────────────────────────────

    @Test(priority = 1, description = "LCS: identical strings = 1.0")
    public void testLCS_identicalStrings() {
        double score = lcs.similarity("submit_btn", "submit_btn");
        Assert.assertEquals(score, 1.0, 0.001, "Identical strings should score 1.0");
    }

    @Test(priority = 2, description = "LCS: completely different = 0.0")
    public void testLCS_completelydifferent() {
        double score = lcs.similarity("aaa", "bbb");
        Assert.assertEquals(score, 0.0, 0.001, "Completely different strings should score 0.0");
    }

    @Test(priority = 3, description = "LCS: partial match returns mid range score")
    public void testLCS_partialMatch() {
        double score = lcs.similarity("submit_btn", "submit_button");
        Assert.assertTrue(score > 0.6 && score < 1.0,
                "Partial match 'submit_btn' vs 'submit_button' should score between 0.6 and 1.0, got: " + score);
    }

    @Test(priority = 4, description = "LCS: null inputs handled gracefully")
    public void testLCS_nullInputs() {
        Assert.assertEquals(lcs.similarity(null, null), 1.0, 0.001);
        Assert.assertEquals(lcs.similarity(null, "test"), 0.0, 0.001);
        Assert.assertEquals(lcs.similarity("test", null), 0.0, 0.001);
    }

    @Test(priority = 5, description = "LCS: case-insensitive comparison")
    public void testLCS_caseInsensitive() {
        double score = lcs.similarity("SubmitButton", "submitbutton");
        Assert.assertEquals(score, 1.0, 0.001, "Should be case-insensitive");
    }

    @Test(priority = 6, description = "LCS: version suffix similarity")
    public void testLCS_versionSuffix() {
        double score = lcs.similarity("submit_btn", "submit_btn_v2");
        Assert.assertTrue(score > 0.7, "Version suffix should still match well: " + score);
    }

    @Test(priority = 7, description = "Jaccard similarity for CSS class sets")
    public void testJaccard_classSets() {
        double score = lcs.jaccardSimilarity("btn primary large", "btn primary");
        Assert.assertTrue(score > 0.5, "Jaccard for overlapping class sets: " + score);

        double noOverlap = lcs.jaccardSimilarity("btn-primary", "input-field");
        Assert.assertTrue(noOverlap < 0.4, "No overlap should score low: " + noOverlap);
    }

    @Test(priority = 8, description = "Weighted score computation")
    public void testWeightedScore() {
        double score = lcs.computeWeightedScore(
                "submit_btn",  "Submit",      "btn primary",  // reference
                "submit_btn",  "Submit",      "btn secondary",// candidate
                0.25, 0.45, 0.20);
        // id perfect, text perfect, class partial → should be high
        Assert.assertTrue(score > 0.7, "Weighted score for mostly matching element: " + score);
    }

    // ── Healing Cache Tests ───────────────────────────────────────────────

    @Test(priority = 10, description = "Cache: store and lookup")
    public void testCache_storeAndLookup() {
        cache.store("id", "old_submit_btn",
                "By.id: new_submit_btn", "Layer1-AttributeSwap", 0.9);
        String result = cache.lookup("id", "old_submit_btn");
        Assert.assertNotNull(result, "Stored entry should be found");
        Assert.assertTrue(result.contains("new_submit_btn"), "Should return healed locator");
    }

    @Test(priority = 11, description = "Cache: case-insensitive key lookup")
    public void testCache_caseInsensitive() {
        cache.store("id", "Username_Field", "By.id: username", "Test", 0.85);
        String result = cache.lookup("ID", "USERNAME_FIELD"); // different case
        Assert.assertNotNull(result, "Cache should be case-insensitive");
    }

    @Test(priority = 12, description = "Cache: miss returns null")
    public void testCache_miss() {
        String result = cache.lookup("id", "nonexistent_element_xyz_12345");
        Assert.assertNull(result, "Cache miss should return null");
    }

    @Test(priority = 13, description = "Cache: invalidate removes entry")
    public void testCache_invalidate() {
        cache.store("name", "test_field", "By.name: test_field_new", "Test", 0.8);
        cache.invalidate("name", "test_field");
        String result = cache.lookup("name", "test_field");
        Assert.assertNull(result, "Invalidated entry should not be found");
    }

    // ── ElementContext Tests ──────────────────────────────────────────────

    @Test(priority = 20, description = "ElementContext: locator type extraction")
    public void testElementContext_locatorTypeExtraction() {
        ElementContext ctx = new ElementContext(By.id("submit_btn"));
        Assert.assertEquals(ctx.getLocatorType(), "id");
        Assert.assertEquals(ctx.getLocatorValue(), "submit_btn");

        ElementContext ctxXpath = new ElementContext(By.xpath("//button[@id='submit']"));
        Assert.assertEquals(ctxXpath.getLocatorType(), "xpath");

        ElementContext ctxCss = new ElementContext(By.cssSelector(".btn-primary"));
        Assert.assertEquals(ctxCss.getLocatorType(), "css");
    }

    @Test(priority = 21, description = "ElementContext: builder pattern works")
    public void testElementContext_builder() {
        ElementContext ctx = new ElementContext(By.id("test"))
                .withPageTitle("Test Page")
                .withPageUrl("https://example.com")
                .withTagName("button")
                .withInnerText("Submit")
                .withDomDepth(5)
                .withFailureCount(2);

        Assert.assertEquals(ctx.getPageTitle(), "Test Page");
        Assert.assertEquals(ctx.getTagName(), "button");
        Assert.assertEquals(ctx.getInnerText(), "Submit");
        Assert.assertEquals(ctx.getDomDepth(), 5);
        Assert.assertEquals(ctx.getFailureCount(), 2);
    }

    // ── HealingResult Tests ───────────────────────────────────────────────

    @Test(priority = 30, description = "HealingResult: success state is tracked correctly")
    public void testHealingResult_successState() {
        HealingResult result = new HealingResult(By.id("old_btn"));
        Assert.assertFalse(result.isSuccess(), "New result should not be success");
        Assert.assertEquals(result.getStatus(), HealingResult.Status.NOT_ATTEMPTED);

        result.markOverallSuccess(By.id("new_btn"),
                HealingResult.HealingLayer.LAYER_1_CACHE_RULES, 0.9, "Cache Hit");

        Assert.assertTrue(result.isSuccess());
        Assert.assertEquals(result.getSuccessLayer(), HealingResult.HealingLayer.LAYER_1_CACHE_RULES);
        Assert.assertEquals(result.getConfidenceScore(), 0.9, 0.001);
    }

    @Test(priority = 31, description = "HealingResult: failure state recorded correctly")
    public void testHealingResult_failureState() {
        HealingResult result = new HealingResult(By.xpath("//button[@id='old']"));
        result.markOverallFailed("All layers exhausted");

        Assert.assertFalse(result.isSuccess());
        Assert.assertEquals(result.getStatus(), HealingResult.Status.FAILED);
    }

    @Test(priority = 32, description = "HealingResult: layer attempts tracked independently")
    public void testHealingResult_layerAttempts() {
        HealingResult result = new HealingResult(By.id("test"));

        result.getLayer1Attempt().markFailed(120, "Case variation failed");
        result.getLayer2Attempt().markFailed(3500, "Healenium backend unavailable");
        result.getLayer3Attempt().markSuccess(By.xpath("//button[text()='Submit']"),
                0.82, 1200, "Text search");

        Assert.assertEquals(result.getLayer1Attempt().getStatus(), HealingResult.Status.FAILED);
        Assert.assertEquals(result.getLayer2Attempt().getStatus(), HealingResult.Status.FAILED);
        Assert.assertEquals(result.getLayer3Attempt().getStatus(), HealingResult.Status.SUCCESS);
        Assert.assertEquals(result.getLayer4Attempt().getStatus(), HealingResult.Status.NOT_ATTEMPTED);
        Assert.assertEquals(result.getLayer3Attempt().getScore(), 0.82, 0.001);
    }

    @Test(priority = 33, description = "HealingResult: summary string is meaningful")
    public void testHealingResult_summary() {
        HealingResult success = new HealingResult(By.id("old"));
        success.markOverallSuccess(By.id("new"),
                HealingResult.HealingLayer.LAYER_4_LLM_AI, 0.95, "Claude AI suggestion");

        String summary = success.getSummary();
        Assert.assertTrue(summary.contains("HEALED"), "Success summary should say HEALED");
        Assert.assertTrue(summary.contains("Claude"), "Summary should mention layer");

        HealingResult failure = new HealingResult(By.id("broken"));
        failure.markOverallFailed("No matching element found");
        Assert.assertTrue(failure.getSummary().contains("FAILED"), "Failure summary should say FAILED");
    }

    // ── LCS Algorithm Edge Cases ──────────────────────────────────────────

    @Test(priority = 40, description = "LCS: empty strings")
    public void testLCS_emptyStrings() {
        Assert.assertEquals(lcs.similarity("", ""), 1.0, 0.001);
        Assert.assertEquals(lcs.similarity("", "test"), 0.0, 0.001);
        Assert.assertEquals(lcs.similarity("test", ""), 0.0, 0.001);
    }

    @Test(priority = 41, description = "LCS: single character strings")
    public void testLCS_singleChar() {
        Assert.assertEquals(lcs.similarity("a", "a"), 1.0, 0.001);
        Assert.assertEquals(lcs.similarity("a", "b"), 0.0, 0.001);
    }

    @Test(priority = 42, description = "LCS: realistic locator comparison — submit_btn_v2 vs submit_btn")
    public void testLCS_realisticLocators() {
        double score = lcs.similarity("login-submit-btn", "login_submit_btn");
        Assert.assertTrue(score > 0.8, "Hyphen vs underscore should still match well: " + score);

        double scoreNew = lcs.similarity("user-email-input", "userEmailInput");
        // Different conventions but same semantic — score may be lower
        Assert.assertTrue(scoreNew > 0.4, "Camel vs kebab case: " + scoreNew);
    }
}
