package com.healing.layers;

import com.healing.config.HealingConfig;
import com.healing.core.IHealingLayer;
import com.healing.models.ElementContext;
import com.healing.models.HealingResult;
import com.healing.utils.LCSAlgorithm;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

/**
 * =====================================================================
 * LAYER 3 - APPROACH 3: Advanced Multi-Strategy Fallback Engine
 * =====================================================================
 *
 * Strategies attempted (in priority order):
 *  3.1  Text-Based Search:      Find by exact/partial visible text
 *  3.2  Fuzzy Attribute Match:  LCS score across all page elements
 *  3.3  Data-Attribute Search:  data-testid, data-cy, aria-label, etc.
 *  3.4  Structural Hierarchy:   Navigate parent→child relationships
 *  3.5  XPath Simplification:   Strip complex predicates, try simpler paths
 *  3.6  Sibling-Based Search:   Find element near known stable siblings
 *  3.7  Tag+Class Combo:        Tag name + partial class match
 *
 * Uses LCS algorithm for scored matching (O(m×n) DP).
 *
 * Speed: 1–4 seconds
 * Target success rate: 15-22%
 */
public class AdvancedFallbackHealingLayer implements IHealingLayer {

    private static final Logger log = LoggerFactory.getLogger(AdvancedFallbackHealingLayer.class);
    private final HealingConfig config = HealingConfig.getInstance();
    private final LCSAlgorithm lcs = new LCSAlgorithm();

    @Override
    public String getLayerName() { return "Layer 3 - Advanced Fallback Engine"; }

    @Override
    public boolean isEnabled() { return config.isLayer3Enabled(); }

    @Override
    public int getLayerPriority() { return 3; }

    @Override
    public WebElement attemptHealing(ElementContext ctx, WebDriver driver, HealingResult result) {
        long start = System.currentTimeMillis();
        log.info("▶ [Layer 3] Starting advanced fallback for: {}", ctx.toCompactString());

        HealingResult.LayerAttempt attempt = result.getLayer3Attempt();
        double threshold = config.getLayer3ScoreThreshold();

        // ── Strategy 3.1: Text-Based Search ──
        WebElement textFound = strategy_textSearch(ctx, driver);
        if (textFound != null) {
            return finalizeSuccess(attempt, result, textFound, ctx, start, "Text-Based Search", 0.88);
        }

        // ── Strategy 3.2: Fuzzy Attribute Match (LCS scored) ──
        WebElement fuzzyFound = strategy_fuzzyAttributeMatch(ctx, driver, threshold);
        if (fuzzyFound != null) {
            return finalizeSuccess(attempt, result, fuzzyFound, ctx, start, "Fuzzy LCS Attribute Match", 0.82);
        }

        // ── Strategy 3.3: Data-Attribute Search ──
        WebElement dataAttrFound = strategy_dataAttributeSearch(ctx, driver);
        if (dataAttrFound != null) {
            return finalizeSuccess(attempt, result, dataAttrFound, ctx, start, "Data Attribute Search", 0.85);
        }

        // ── Strategy 3.4: Structural Hierarchy ──
        WebElement hierFound = strategy_structuralHierarchy(ctx, driver);
        if (hierFound != null) {
            return finalizeSuccess(attempt, result, hierFound, ctx, start, "Structural Hierarchy", 0.75);
        }

        // ── Strategy 3.5: XPath Simplification ──
        if ("xpath".equals(ctx.getLocatorType())) {
            WebElement simplifiedFound = strategy_xpathSimplification(ctx, driver);
            if (simplifiedFound != null) {
                return finalizeSuccess(attempt, result, simplifiedFound, ctx, start, "XPath Simplification", 0.75);
            }
        }

        // ── Strategy 3.6: Sibling-Based Search ──
        WebElement siblingFound = strategy_siblingSearch(ctx, driver);
        if (siblingFound != null) {
            return finalizeSuccess(attempt, result, siblingFound, ctx, start, "Sibling-Based Search", 0.72);
        }

        // ── Strategy 3.7: Tag + Class Combo ──
        WebElement tagClassFound = strategy_tagClassCombo(ctx, driver, threshold);
        if (tagClassFound != null) {
            return finalizeSuccess(attempt, result, tagClassFound, ctx, start, "Tag+Class Combo", 0.70);
        }

        long elapsed = System.currentTimeMillis() - start;
        attempt.markFailed(elapsed, "All Layer 3 strategies exhausted");
        log.info("❌ [Layer 3] ALL strategies FAILED in {}ms — escalating to Layer 4 (LLM AI)", elapsed);
        return null;
    }

    // ── STRATEGY 3.1: Text-Based Search ───────────────────────────────────

    private WebElement strategy_textSearch(ElementContext ctx, WebDriver driver) {
        String text = ctx.getInnerText();
        String value = ctx.getLocatorValue();

        // Collect candidate texts to search
        List<String> searchTexts = new ArrayList<>();
        if (text != null && !text.isEmpty()) searchTexts.add(text);

        // Extract text from xpath like //button[text()='Submit'] or contains(@text,'Submit')
        String extractedText = extractTextFromLocator(value);
        if (extractedText != null && !searchTexts.contains(extractedText)) {
            searchTexts.add(extractedText);
        }

        for (String searchText : searchTexts) {
            // Exact match via link text
            WebElement el = tryLocate(By.linkText(searchText), driver);
            if (el != null) return el;

            // Partial match
            el = tryLocate(By.partialLinkText(searchText), driver);
            if (el != null) return el;

            // XPath text() match
            el = tryLocate(By.xpath(String.format("//*[normalize-space(text())='%s']", searchText)), driver);
            if (el != null) return el;

            // Case-insensitive via translate
            String lower = searchText.toLowerCase();
            el = tryLocate(By.xpath(String.format(
                    "//*[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'%s')]",
                    lower)), driver);
            if (el != null) return el;
        }
        return null;
    }

    // ── STRATEGY 3.2: Fuzzy Attribute Match ───────────────────────────────

    private WebElement strategy_fuzzyAttributeMatch(ElementContext ctx, WebDriver driver, double threshold) {
        String originalValue = ctx.getLocatorValue();
        if (originalValue == null || originalValue.isEmpty()) return null;

        try {
            // Get all elements with id, name, or data-testid
            List<WebElement> candidates = new ArrayList<>();
            candidates.addAll(safeFind(driver, By.xpath("//*[@id]")));
            candidates.addAll(safeFind(driver, By.xpath("//*[@name]")));
            candidates.addAll(safeFind(driver, By.xpath("//*[@data-testid]")));

            WebElement best = null;
            double bestScore = threshold;

            for (WebElement el : candidates) {
                double score = scoreCandidateElement(el, ctx);
                if (score > bestScore) {
                    bestScore = score;
                    best = el;
                }
            }

            if (best != null) {
                log.debug("[Layer 3] Fuzzy best match score: {:.2f}", bestScore);
            }
            return best;
        } catch (Exception e) {
            log.debug("Fuzzy strategy error: {}", e.getMessage());
            return null;
        }
    }

    private double scoreCandidateElement(WebElement el, ElementContext ctx) {
        try {
            String candId    = safeAttr(el, "id");
            String candName  = safeAttr(el, "name");
            String candClass = safeAttr(el, "class");
            String candText  = el.getText();
            String value     = ctx.getLocatorValue();

            double idScore    = Math.max(lcs.similarity(value, candId), lcs.similarity(value, candName));
            double textScore  = lcs.similarity(ctx.getInnerText(), candText);
            double classScore = lcs.jaccardSimilarity(ctx.getAttributes() != null ?
                    ctx.getAttributes().get("class") : null, candClass);

            return (idScore    * config.getWeightAttribute()) +
                   (textScore  * config.getWeightText()) +
                   (classScore * config.getWeightClass());
        } catch (Exception e) {
            return 0.0;
        }
    }

    // ── STRATEGY 3.3: Data-Attribute Search ───────────────────────────────

    private WebElement strategy_dataAttributeSearch(ElementContext ctx, WebDriver driver) {
        String value = ctx.getLocatorValue();
        if (value == null) return null;

        String[] dataAttrs = {"data-testid", "data-cy", "data-qa", "data-id",
                              "aria-label", "aria-labelledby", "placeholder", "title"};
        for (String attr : dataAttrs) {
            // Try exact
            WebElement el = tryLocate(By.cssSelector("[" + attr + "='" + value + "']"), driver);
            if (el != null) return el;
            // Try contains
            el = tryLocate(By.cssSelector("[" + attr + "*='" + value + "']"), driver);
            if (el != null) return el;
        }

        // Also try role + text combos for accessible elements
        if (ctx.getTagName() != null) {
            String tag = ctx.getTagName();
            String text = ctx.getInnerText();
            if (text != null && !text.isEmpty()) {
                WebElement el = tryLocate(By.xpath(
                        String.format("//%s[contains(text(),'%s')]", tag, text)), driver);
                if (el != null) return el;
            }
        }
        return null;
    }

    // ── STRATEGY 3.4: Structural Hierarchy ────────────────────────────────

    private WebElement strategy_structuralHierarchy(ElementContext ctx, WebDriver driver) {
        String parentXPath = ctx.getParentXPath();
        if (parentXPath == null) return null;

        // Remove last node to get parent path
        int lastSlash = parentXPath.lastIndexOf("/");
        if (lastSlash > 0) {
            String parentPath = parentXPath.substring(0, lastSlash);
            String tagName = ctx.getTagName() != null ? ctx.getTagName() : "*";

            // Navigate from parent
            WebElement el = tryLocate(By.xpath(parentPath + "/" + tagName), driver);
            if (el != null) return el;

            // First child of type
            el = tryLocate(By.xpath(parentPath + "/" + tagName + "[1]"), driver);
            if (el != null) return el;
        }
        return null;
    }

    // ── STRATEGY 3.5: XPath Simplification ────────────────────────────────

    private WebElement strategy_xpathSimplification(ElementContext ctx, WebDriver driver) {
        String xpath = ctx.getLocatorValue();
        if (xpath == null) return null;

        List<String> simplifications = new ArrayList<>();

        // Remove index predicates: [1], [2], etc.
        simplifications.add(xpath.replaceAll("\\[\\d+\\]", ""));

        // Remove all predicates entirely
        simplifications.add(xpath.replaceAll("\\[.*?\\]", ""));

        // Convert //div/.../button to //button
        if (xpath.contains("/")) {
            String lastSegment = xpath.substring(xpath.lastIndexOf("/") + 1);
            if (!lastSegment.isEmpty() && !lastSegment.equals("/")) {
                simplifications.add("//" + lastSegment);
                simplifications.add("//" + lastSegment.replaceAll("\\[.*?\\]", ""));
            }
        }

        // Try descendant axis: /a/b/c → //c
        String[] parts = xpath.split("/");
        if (parts.length > 0) {
            String lastPart = parts[parts.length - 1];
            simplifications.add("//" + lastPart);
        }

        for (String simplified : simplifications) {
            if (!simplified.equals(xpath) && !simplified.isEmpty()) {
                WebElement el = tryLocate(By.xpath(simplified), driver);
                if (el != null) {
                    log.debug("[Layer 3] XPath simplified: {} → {}", xpath, simplified);
                    return el;
                }
            }
        }
        return null;
    }

    // ── STRATEGY 3.6: Sibling-Based Search ────────────────────────────────

    private WebElement strategy_siblingSearch(ElementContext ctx, WebDriver driver) {
        List<String> siblings = ctx.getSiblingTexts();
        if (siblings == null || siblings.isEmpty()) return null;

        String tagName = ctx.getTagName() != null ? ctx.getTagName() : "*";

        for (String sibText : siblings) {
            if (sibText == null || sibText.trim().isEmpty()) continue;
            // Find sibling by text, then navigate to adjacent element
            try {
                String xpath = String.format(
                        "//*[normalize-space(text())='%s']/following-sibling::%s[1]",
                        sibText.trim(), tagName);
                WebElement el = tryLocate(By.xpath(xpath), driver);
                if (el != null) return el;

                xpath = String.format(
                        "//*[normalize-space(text())='%s']/preceding-sibling::%s[1]",
                        sibText.trim(), tagName);
                el = tryLocate(By.xpath(xpath), driver);
                if (el != null) return el;
            } catch (Exception ignored) {}
        }
        return null;
    }

    // ── STRATEGY 3.7: Tag + Class Combo ───────────────────────────────────

    private WebElement strategy_tagClassCombo(ElementContext ctx, WebDriver driver, double threshold) {
        Map<String, String> attrs = ctx.getAttributes();
        if (attrs == null) return null;

        String className = attrs.get("class");
        String tagName = ctx.getTagName();
        if (className == null || tagName == null) return null;

        // Split classes and try combinations
        String[] classes = className.split("\\s+");
        for (String cls : classes) {
            if (cls.length() < 3) continue; // Skip trivial classes
            WebElement el = tryLocate(By.cssSelector(tagName + "." + cls), driver);
            if (el != null) return el;
        }

        // Try first two classes combo
        if (classes.length >= 2) {
            WebElement el = tryLocate(By.cssSelector(tagName + "." + classes[0] + "." + classes[1]), driver);
            if (el != null) return el;
        }
        return null;
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private WebElement finalizeSuccess(HealingResult.LayerAttempt attempt, HealingResult result,
                                        WebElement el, ElementContext ctx,
                                        long start, String strategy, double score) {
        long elapsed = System.currentTimeMillis() - start;
        By byRef = ctx.getOriginalLocator(); // best approximation; element object returned
        attempt.markSuccess(byRef, score, elapsed, strategy);
        result.markOverallSuccess(byRef, HealingResult.HealingLayer.LAYER_3_ADVANCED_FALLBACK,
                score, strategy);
        log.info("✅ [Layer 3] HEALED via '{}' in {}ms | Score: {}", strategy, elapsed, score);
        return el;
    }

    private WebElement tryLocate(By by, WebDriver driver) {
        try {
            WebElement el = driver.findElement(by);
            return (el != null) ? el : null;
        } catch (org.openqa.selenium.NoSuchElementException ignored) {
            return null;
        } catch (Exception e) {
            log.trace("Layer 3 locate error: {}", e.getMessage());
            return null;
        }
    }

    private List<WebElement> safeFind(WebDriver driver, By by) {
        try { return driver.findElements(by); }
        catch (Exception e) { return Collections.emptyList(); }
    }

    private String safeAttr(WebElement el, String attr) {
        try { String v = el.getAttribute(attr); return v != null ? v : ""; }
        catch (Exception e) { return ""; }
    }

    private String extractTextFromLocator(String value) {
        if (value == null) return null;
        // Match: text()='XXX', @text='XXX', contains(@text,'XXX')
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                "(?:text\\(\\)|@text|@content-desc)\\s*[=,]\\s*['\"]([^'\"]+)['\"]");
        java.util.regex.Matcher m = p.matcher(value);
        if (m.find()) return m.group(1);
        return null;
    }
}
