package com.healing.layers;

import com.google.gson.*;
import com.healing.config.HealingConfig;
import com.healing.core.IHealingLayer;
import com.healing.models.ElementContext;
import com.healing.models.HealingResult;
import com.healing.utils.HealingCache;
import org.openqa.selenium.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * =====================================================================
 * LAYER 4 - FINAL APPROACH: Claude LLM AI-Powered Healing
 * =====================================================================
 *
 * When all 3 previous layers fail, this layer calls the Claude AI API
 * with rich DOM context to generate intelligent locator alternatives.
 *
 * What it sends to the LLM:
 *  - Original locator type + value
 *  - Page title, URL
 *  - Truncated DOM (page source ~8KB)
 *  - Element metadata (tag, text, attributes)
 *  - Parent XPath context
 *  - Error message
 *
 * What it receives:
 *  - JSON array of candidate locators with confidence scores
 *  - Explanation of the healing strategy
 *
 * Speed: 3–15 seconds
 * Target success rate: 60-80% of cases that reach this layer
 *
 * Configuration:
 *  healing.layer4.enabled=true
 *  healing.layer4.llm.apiKey=sk-ant-...  (or ANTHROPIC_API_KEY env var)
 *  healing.layer4.llm.model=claude-sonnet-4-20250514
 */
public class LLMAIHealingLayer implements IHealingLayer {

    private static final Logger log = LoggerFactory.getLogger(LLMAIHealingLayer.class);
    private final HealingConfig config = HealingConfig.getInstance();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final HealingCache cache;

    public LLMAIHealingLayer() {
        this.cache = HealingCache.getInstance(config.getCacheMaxSize());
    }

    @Override
    public String getLayerName() { return "Layer 4 - Claude LLM AI"; }

    @Override
    public boolean isEnabled() { return config.isLayer4Enabled(); }

    @Override
    public int getLayerPriority() { return 4; }

    @Override
    public WebElement attemptHealing(ElementContext ctx, WebDriver driver, HealingResult result) {
        long start = System.currentTimeMillis();
        log.info("▶ [Layer 4] Invoking Claude AI for healing: {}", ctx.toCompactString());

        HealingResult.LayerAttempt attempt = result.getLayer4Attempt();

        String apiKey = config.getLlmApiKey();
        if (apiKey == null || apiKey.isEmpty()) {
            long elapsed = System.currentTimeMillis() - start;
            attempt.markFailed(elapsed,
                    "No LLM API key configured. Set ANTHROPIC_API_KEY env var or " +
                    "healing.layer4.llm.apiKey in healing-config.properties");
            log.warn("⚠️  [Layer 4] No API key — LLM healing skipped");
            return null;
        }

        try {
            // Build the prompt
            String prompt = buildPrompt(ctx);
            log.debug("[Layer 4] Sending prompt to Claude ({} chars)", prompt.length());

            // Call Claude API
            String apiResponse = callClaudeAPI(prompt, apiKey);
            if (apiResponse == null) {
                long elapsed = System.currentTimeMillis() - start;
                attempt.markFailed(elapsed, "Claude API returned null response");
                return null;
            }

            // Parse locator candidates from response
            List<LLMLocatorCandidate> candidates = parseLocatorCandidates(apiResponse);
            log.info("[Layer 4] Claude suggested {} locator candidates", candidates.size());

            // Try each candidate
            for (LLMLocatorCandidate candidate : candidates) {
                WebElement found = tryLocator(candidate, driver);
                if (found != null) {
                    long elapsed = System.currentTimeMillis() - start;
                    By healedBy = candidate.toBy();
                    attempt.markSuccess(healedBy, candidate.confidence, elapsed,
                            "Claude AI: " + candidate.strategy);
                    result.markOverallSuccess(healedBy, HealingResult.HealingLayer.LAYER_4_LLM_AI,
                            candidate.confidence, "Claude AI - " + candidate.strategy);

                    // Cache for future runs
                    cache.store(ctx.getLocatorType(), ctx.getLocatorValue(),
                            healedBy.toString(), "Claude AI", candidate.confidence);

                    log.info("✅ [Layer 4] HEALED via Claude AI in {}ms | Strategy: {} | Confidence: {}",
                            elapsed, candidate.strategy, candidate.confidence);
                    return found;
                }
            }

            long elapsed = System.currentTimeMillis() - start;
            attempt.markFailed(elapsed,
                    "Claude suggested " + candidates.size() + " candidates but none worked on the page");
            log.info("❌ [Layer 4] Claude candidates all failed ({} tried) in {}ms",
                    candidates.size(), elapsed);

        } catch (Exception e) {
            long elapsed = System.currentTimeMillis() - start;
            attempt.markFailed(elapsed, "Claude AI error: " + e.getMessage());
            log.error("❌ [Layer 4] Claude AI error: {}", e.getMessage(), e);
        }

        return null;
    }

    // ── Prompt Building ────────────────────────────────────────────────────

    private String buildPrompt(ElementContext ctx) {
        StringBuilder sb = new StringBuilder();
        sb.append("You are an expert Selenium test automation engineer specializing in locator healing.\n\n");
        sb.append("A Selenium test has FAILED to find an element. Analyze the context and suggest ");
        sb.append("up to 5 alternative locators that are most likely to find the correct element.\n\n");

        sb.append("## FAILED LOCATOR\n");
        sb.append("- Type: ").append(ctx.getLocatorType()).append("\n");
        sb.append("- Value: ").append(ctx.getLocatorValue()).append("\n");
        sb.append("- Error: ").append(ctx.getExceptionMessage() != null ? ctx.getExceptionMessage() : "NoSuchElementException").append("\n\n");

        sb.append("## PAGE CONTEXT\n");
        sb.append("- URL: ").append(ctx.getPageUrl() != null ? ctx.getPageUrl() : "unknown").append("\n");
        sb.append("- Title: ").append(ctx.getPageTitle() != null ? ctx.getPageTitle() : "unknown").append("\n\n");

        if (ctx.getTagName() != null || ctx.getInnerText() != null) {
            sb.append("## ELEMENT METADATA (from last known state)\n");
            if (ctx.getTagName() != null)   sb.append("- Tag: ").append(ctx.getTagName()).append("\n");
            if (ctx.getInnerText() != null) sb.append("- Text: ").append(ctx.getInnerText()).append("\n");
            if (ctx.getAttributes() != null && !ctx.getAttributes().isEmpty()) {
                sb.append("- Attributes: ").append(ctx.getAttributes()).append("\n");
            }
            if (ctx.getParentXPath() != null) sb.append("- Parent Path: ").append(ctx.getParentXPath()).append("\n");
            sb.append("\n");
        }

        if (ctx.getPageSource() != null) {
            // Truncate page source intelligently (keep first 8KB)
            String source = ctx.getPageSource();
            if (source.length() > 8000) source = source.substring(0, 8000) + "\n... [TRUNCATED]";
            sb.append("## PAGE SOURCE (truncated)\n```html\n");
            sb.append(source).append("\n```\n\n");
        }

        sb.append("## INSTRUCTIONS\n");
        sb.append("Respond ONLY with a valid JSON array. No explanations outside the JSON.\n");
        sb.append("Each item in the array must have these exact fields:\n");
        sb.append("{\n");
        sb.append("  \"locatorType\": \"id\" | \"name\" | \"xpath\" | \"css\" | \"linkText\" | \"partialLinkText\" | \"className\",\n");
        sb.append("  \"locatorValue\": \"the actual locator string\",\n");
        sb.append("  \"confidence\": 0.0-1.0 (your confidence this will work),\n");
        sb.append("  \"strategy\": \"brief explanation of why this should work\"\n");
        sb.append("}\n\n");
        sb.append("Order candidates from highest to lowest confidence. ");
        sb.append("Prefer stable locators (data-testid, aria-label, text) over fragile ones (index-based xpath).\n\n");
        sb.append("JSON response:");

        return sb.toString();
    }

    // ── API Call ────────────────────────────────────────────────────────────

    private String callClaudeAPI(String prompt, String apiKey) {
        int maxRetries = config.getLlmMaxRetries();
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                String response = doApiCall(prompt, apiKey);
                if (response != null) return response;
            } catch (Exception e) {
                log.warn("[Layer 4] API attempt {}/{} failed: {}", attempt, maxRetries, e.getMessage());
                if (attempt < maxRetries) {
                    try { Thread.sleep(1000L * attempt); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
                }
            }
        }
        return null;
    }

    private String doApiCall(String prompt, String apiKey) throws Exception {
        URL url = new URL(config.getLlmApiUrl());
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout((int) config.getLlmTimeoutMs());
        conn.setReadTimeout((int) config.getLlmTimeoutMs());
        conn.setDoOutput(true);

        // Headers for Anthropic API
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("x-api-key", apiKey);
        conn.setRequestProperty("anthropic-version", "2023-06-01");

        // Request body
        JsonObject body = new JsonObject();
        body.addProperty("model", config.getLlmModel());
        body.addProperty("max_tokens", config.getLlmMaxTokens());

        JsonArray messages = new JsonArray();
        JsonObject userMsg = new JsonObject();
        userMsg.addProperty("role", "user");
        userMsg.addProperty("content", prompt);
        messages.add(userMsg);
        body.add("messages", messages);

        String requestJson = gson.toJson(body);
        log.debug("[Layer 4] Claude API request body length: {}", requestJson.length());

        try (OutputStream os = conn.getOutputStream()) {
            os.write(requestJson.getBytes(StandardCharsets.UTF_8));
        }

        int responseCode = conn.getResponseCode();
        InputStream inputStream = (responseCode < 400) ? conn.getInputStream() : conn.getErrorStream();

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append("\n");
            String responseBody = sb.toString();

            if (responseCode != 200) {
                log.error("[Layer 4] Claude API HTTP {}: {}", responseCode, responseBody);
                return null;
            }

            // Extract text from Anthropic response format
            return extractTextFromResponse(responseBody);
        }
    }

    private String extractTextFromResponse(String rawResponse) {
        try {
            JsonObject json = JsonParser.parseString(rawResponse).getAsJsonObject();
            JsonArray content = json.getAsJsonArray("content");
            if (content != null && content.size() > 0) {
                JsonObject first = content.get(0).getAsJsonObject();
                if ("text".equals(first.get("type").getAsString())) {
                    return first.get("text").getAsString();
                }
            }
        } catch (Exception e) {
            log.warn("[Layer 4] Could not parse Claude response: {}", e.getMessage());
        }
        return rawResponse; // fallback: try to parse as-is
    }

    // ── Response Parsing ───────────────────────────────────────────────────

    private List<LLMLocatorCandidate> parseLocatorCandidates(String response) {
        List<LLMLocatorCandidate> candidates = new ArrayList<>();
        try {
            // Strip markdown code blocks if present
            String cleaned = response.trim();
            if (cleaned.startsWith("```")) {
                cleaned = cleaned.replaceAll("```json\\n?", "").replaceAll("```\\n?", "").trim();
            }

            // Find JSON array start
            int arrayStart = cleaned.indexOf("[");
            int arrayEnd = cleaned.lastIndexOf("]");
            if (arrayStart >= 0 && arrayEnd > arrayStart) {
                cleaned = cleaned.substring(arrayStart, arrayEnd + 1);
            }

            JsonArray arr = JsonParser.parseString(cleaned).getAsJsonArray();
            for (JsonElement el : arr) {
                try {
                    JsonObject obj = el.getAsJsonObject();
                    LLMLocatorCandidate candidate = new LLMLocatorCandidate();
                    candidate.locatorType  = obj.has("locatorType") ? obj.get("locatorType").getAsString() : "xpath";
                    candidate.locatorValue = obj.has("locatorValue") ? obj.get("locatorValue").getAsString() : null;
                    candidate.confidence   = obj.has("confidence") ? obj.get("confidence").getAsDouble() : 0.5;
                    candidate.strategy     = obj.has("strategy") ? obj.get("strategy").getAsString() : "LLM suggestion";

                    if (candidate.locatorValue != null && !candidate.locatorValue.isEmpty()) {
                        candidates.add(candidate);
                    }
                } catch (Exception e) {
                    log.trace("Failed to parse candidate: {}", e.getMessage());
                }
            }

            // Sort by confidence desc
            candidates.sort((a, b) -> Double.compare(b.confidence, a.confidence));

        } catch (Exception e) {
            log.warn("[Layer 4] Failed to parse LLM candidates from: {} | Error: {}",
                    response.substring(0, Math.min(200, response.length())), e.getMessage());
        }
        return candidates;
    }

    private WebElement tryLocator(LLMLocatorCandidate candidate, WebDriver driver) {
        By by = candidate.toBy();
        if (by == null) return null;
        try {
            WebElement el = driver.findElement(by);
            log.debug("[Layer 4] Candidate FOUND: {} → {}", candidate.locatorType, candidate.locatorValue);
            return el;
        } catch (org.openqa.selenium.NoSuchElementException ignored) {
            log.debug("[Layer 4] Candidate MISS: {} → {}", candidate.locatorType, candidate.locatorValue);
            return null;
        } catch (Exception e) {
            log.trace("[Layer 4] Locate error: {}", e.getMessage());
            return null;
        }
    }

    // ── Inner model ────────────────────────────────────────────────────────

    private static class LLMLocatorCandidate {
        String locatorType;
        String locatorValue;
        double confidence;
        String strategy;

        By toBy() {
            if (locatorValue == null || locatorValue.isEmpty()) return null;
            switch (locatorType.toLowerCase()) {
                case "id":               return By.id(locatorValue);
                case "name":             return By.name(locatorValue);
                case "xpath":            return By.xpath(locatorValue);
                case "css":
                case "cssselector":      return By.cssSelector(locatorValue);
                case "classname":        return By.className(locatorValue);
                case "linktext":         return By.linkText(locatorValue);
                case "partiallinktext":  return By.partialLinkText(locatorValue);
                case "tagname":          return By.tagName(locatorValue);
                default:
                    try { return By.xpath(locatorValue); }
                    catch (Exception e) { return null; }
            }
        }

        @Override
        public String toString() {
            return String.format("%s:'%s' (confidence=%.2f, strategy='%s')",
                    locatorType, locatorValue, confidence, strategy);
        }
    }
}
