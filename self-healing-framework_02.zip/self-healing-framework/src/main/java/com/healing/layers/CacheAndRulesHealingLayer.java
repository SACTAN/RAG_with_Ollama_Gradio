package com.healing.layers;

import com.healing.config.HealingConfig;
import com.healing.core.IHealingLayer;
import com.healing.models.ElementContext;
import com.healing.models.HealingResult;
import com.healing.utils.HealingCache;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * =====================================================================
 * LAYER 1 - APPROACH 1: Cache Lookup + Quick Rule-Based Healing
 * =====================================================================
 *
 * Strategies attempted in order:
 *  1.1  Cache Hit:          Previously healed locator found instantly
 *  1.2  Case Variation:     Try lowercase/uppercase/titlecase variants
 *  1.3  Attribute Swap:     Try id→name→data-testid→aria-label
 *  1.4  Locator Type Swap:  id→css, name→id, etc.
 *  1.5  Common Prefix:      Strip versioning suffixes (_v2, _new, _old)
 *  1.6  Partial ID Match:   Find element whose id contains the locator value
 *
 * Speed: ~50-200ms
 * Target success rate: 20-25%
 */
public class CacheAndRulesHealingLayer implements IHealingLayer {

    private static final Logger log = LoggerFactory.getLogger(CacheAndRulesHealingLayer.class);
    private final HealingConfig config = HealingConfig.getInstance();
    private final HealingCache cache;

    public CacheAndRulesHealingLayer() {
        this.cache = HealingCache.getInstance(config.getCacheMaxSize());
    }

    @Override
    public String getLayerName() { return "Layer 1 - Cache & Quick Rules"; }

    @Override
    public boolean isEnabled() { return config.isLayer1Enabled(); }

    @Override
    public int getLayerPriority() { return 1; }

    @Override
    public WebElement attemptHealing(ElementContext ctx, WebDriver driver, HealingResult result) {
        long start = System.currentTimeMillis();
        log.info("▶ [Layer 1] Starting healing for: {}", ctx.toCompactString());

        HealingResult.LayerAttempt attempt = result.getLayer1Attempt();

        // ── Strategy 1.1: Cache Lookup ──
        if (config.isCacheEnabled()) {
            WebElement cached = tryCacheLookup(ctx, driver);
            if (cached != null) {
                long elapsed = System.currentTimeMillis() - start;
                By healedBy = buildByFromCached(ctx);
                attempt.markSuccess(healedBy, 1.0, elapsed, "Cache Hit");
                result.markOverallSuccess(healedBy, HealingResult.HealingLayer.LAYER_1_CACHE_RULES,
                        1.0, "Cache Hit");
                log.info("✅ [Layer 1] HEALED via Cache in {}ms", elapsed);
                return cached;
            }
        }

        // ── Strategies 1.2 – 1.6 ──
        List<HealingCandidate> candidates = buildCandidates(ctx);

        for (HealingCandidate candidate : candidates) {
            WebElement found = tryLocate(candidate.by, driver);
            if (found != null) {
                long elapsed = System.currentTimeMillis() - start;
                attempt.markSuccess(candidate.by, candidate.score, elapsed, candidate.strategy);
                result.markOverallSuccess(candidate.by, HealingResult.HealingLayer.LAYER_1_CACHE_RULES,
                        candidate.score, candidate.strategy);

                // Store in cache for next time
                if (config.isCacheEnabled()) {
                    cache.store(ctx.getLocatorType(), ctx.getLocatorValue(),
                            candidate.by.toString(), candidate.strategy, candidate.score);
                }

                log.info("✅ [Layer 1] HEALED via '{}' in {}ms | By: {}",
                        candidate.strategy, elapsed, candidate.by);
                return found;
            }
        }

        long elapsed = System.currentTimeMillis() - start;
        attempt.markFailed(elapsed, "All Layer 1 rules exhausted");
        log.info("❌ [Layer 1] FAILED in {}ms — escalating to Layer 2", elapsed);
        return null;
    }

    // ── Private Helpers ──────────────────────────────────────────────

    private WebElement tryCacheLookup(ElementContext ctx, WebDriver driver) {
        String cachedLocStr = cache.lookup(ctx.getLocatorType(), ctx.getLocatorValue());
        if (cachedLocStr != null) {
            By by = parseByFromString(cachedLocStr);
            if (by != null) {
                WebElement el = tryLocate(by, driver);
                if (el != null) return el;
                // Stale cache entry — invalidate
                cache.invalidate(ctx.getLocatorType(), ctx.getLocatorValue());
            }
        }
        return null;
    }

    private By buildByFromCached(ElementContext ctx) {
        String cached = cache.lookup(ctx.getLocatorType(), ctx.getLocatorValue());
        if (cached != null) return parseByFromString(cached);
        return ctx.getOriginalLocator();
    }

    private List<HealingCandidate> buildCandidates(ElementContext ctx) {
        List<HealingCandidate> candidates = new ArrayList<>();
        String type = ctx.getLocatorType();
        String value = ctx.getLocatorValue();

        // ── 1.2 Case Variations ──
        if (value != null && !value.isEmpty()) {
            addIfNotSame(candidates, type, value.toLowerCase(), value, "Case: lowercase", 0.85);
            addIfNotSame(candidates, type, value.toUpperCase(), value, "Case: UPPERCASE", 0.85);
            addIfNotSame(candidates, type, toTitleCase(value), value, "Case: TitleCase", 0.85);
        }

        // ── 1.3 Attribute Swap ──
        if ("id".equals(type)) {
            candidates.add(new HealingCandidate(By.name(value), "Attr Swap: id→name", 0.80));
            candidates.add(new HealingCandidate(By.cssSelector("[data-testid='" + value + "']"),
                    "Attr Swap: id→data-testid", 0.78));
            candidates.add(new HealingCandidate(By.cssSelector("[aria-label='" + value + "']"),
                    "Attr Swap: id→aria-label", 0.75));
        } else if ("name".equals(type)) {
            candidates.add(new HealingCandidate(By.id(value), "Attr Swap: name→id", 0.80));
            candidates.add(new HealingCandidate(By.cssSelector("[data-testid='" + value + "']"),
                    "Attr Swap: name→data-testid", 0.75));
        } else if ("css".equals(type) && value.contains("#")) {
            // CSS id selector → try By.id
            String idVal = value.replace("#", "").split("[.\\[\\s]")[0];
            candidates.add(new HealingCandidate(By.id(idVal), "CSS→id conversion", 0.80));
        }

        // ── 1.4 Locator Type Swap ──
        if ("xpath".equals(type) && value != null) {
            // Try extracting id from xpath: @id='value'
            String extractedId = extractAttributeFromXPath(value, "id");
            if (extractedId != null)
                candidates.add(new HealingCandidate(By.id(extractedId), "XPath→id extraction", 0.82));

            String extractedName = extractAttributeFromXPath(value, "name");
            if (extractedName != null)
                candidates.add(new HealingCandidate(By.name(extractedName), "XPath→name extraction", 0.80));

            String extractedText = extractAttributeFromXPath(value, "text()");
            if (extractedText != null) {
                candidates.add(new HealingCandidate(By.linkText(extractedText),
                        "XPath→linkText extraction", 0.75));
                candidates.add(new HealingCandidate(By.partialLinkText(extractedText),
                        "XPath→partialLinkText extraction", 0.70));
            }
        }

        // ── 1.5 Common Versioning Suffix Strip ──
        if (value != null) {
            String stripped = value.replaceAll("(_v\\d+|_new|_old|_deprecated|_legacy|-v\\d+|-new)$", "");
            if (!stripped.equals(value)) {
                addIfNotSame(candidates, type, stripped, value, "Strip Version Suffix", 0.78);
            }
            // Also try adding _btn, _link suffixes for common conventions
            candidates.add(new HealingCandidate(byType(type, value + "_btn"), "Suffix add: _btn", 0.72));
            candidates.add(new HealingCandidate(byType(type, value + "-btn"), "Suffix add: -btn", 0.72));
        }

        // ── 1.6 Partial ID / Contains CSS ──
        if ("id".equals(type) && value != null) {
            candidates.add(new HealingCandidate(By.cssSelector("[id*='" + value + "']"),
                    "Partial ID contains", 0.70));
            candidates.add(new HealingCandidate(By.cssSelector("[id^='" + value + "']"),
                    "Partial ID starts-with", 0.72));
            candidates.add(new HealingCandidate(By.cssSelector("[id$='" + value + "']"),
                    "Partial ID ends-with", 0.70));
        }

        return candidates;
    }

    private void addIfNotSame(List<HealingCandidate> list, String type, String newValue,
                               String originalValue, String strategy, double score) {
        if (!newValue.equals(originalValue)) {
            list.add(new HealingCandidate(byType(type, newValue), strategy, score));
        }
    }

    private By byType(String type, String value) {
        switch (type) {
            case "id":              return By.id(value);
            case "name":            return By.name(value);
            case "css":             return By.cssSelector(value);
            case "xpath":           return By.xpath(value);
            case "className":       return By.className(value);
            case "linkText":        return By.linkText(value);
            case "partialLinkText": return By.partialLinkText(value);
            default:                return By.id(value);
        }
    }

    private WebElement tryLocate(By by, WebDriver driver) {
        try {
            WebElement el = driver.findElement(by);
            if (el != null && el.isEnabled()) return el;
        } catch (NoSuchElementException | org.openqa.selenium.StaleElementReferenceException ignored) {
        } catch (Exception e) {
            log.trace("Layer 1 locate error for {}: {}", by, e.getMessage());
        }
        return null;
    }

    private String toTitleCase(String input) {
        if (input == null || input.isEmpty()) return input;
        return Character.toUpperCase(input.charAt(0)) + input.substring(1).toLowerCase();
    }

    private String extractAttributeFromXPath(String xpath, String attr) {
        try {
            String pattern = "@" + attr + "='";
            int start = xpath.indexOf(pattern);
            if (start == -1) return null;
            start += pattern.length();
            int end = xpath.indexOf("'", start);
            if (end == -1) return null;
            return xpath.substring(start, end);
        } catch (Exception e) { return null; }
    }

    private By parseByFromString(String byStr) {
        try {
            if (byStr.contains("By.id:")) return By.id(byStr.split("By.id:")[1].trim());
            if (byStr.contains("By.name:")) return By.name(byStr.split("By.name:")[1].trim());
            if (byStr.contains("By.cssSelector:")) return By.cssSelector(byStr.split("By.cssSelector:")[1].trim());
            if (byStr.contains("By.xpath:")) return By.xpath(byStr.split("By.xpath:")[1].trim());
        } catch (Exception e) { log.trace("Could not parse By from string: {}", byStr); }
        return null;
    }

    private static class HealingCandidate {
        final By by;
        final String strategy;
        final double score;

        HealingCandidate(By by, String strategy, double score) {
            this.by = by;
            this.strategy = strategy;
            this.score = score;
        }
    }
}
