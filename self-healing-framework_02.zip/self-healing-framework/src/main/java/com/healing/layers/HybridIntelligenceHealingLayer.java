package com.healing.layers;

import com.healing.config.HealingConfig;
import com.healing.core.IHealingLayer;
import com.healing.intelligence.domain.LocatorCandidate;
import com.healing.intelligence.factory.HybridIntelligenceFactory;
import com.healing.intelligence.ports.HealingEngine;
import com.healing.models.ElementContext;
import com.healing.models.HealingResult;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class HybridIntelligenceHealingLayer implements IHealingLayer {
    private static final Logger log = LoggerFactory.getLogger(HybridIntelligenceHealingLayer.class);
    private final HealingConfig config = HealingConfig.getInstance();
    private final HealingEngine healingEngine;

    public HybridIntelligenceHealingLayer() {
        this.healingEngine = HybridIntelligenceFactory.create(config);
    }

    @Override
    public WebElement attemptHealing(ElementContext context, WebDriver driver, HealingResult result) {
        long start = System.currentTimeMillis();
        String locatorId = context.getLocatorType() + ":" + context.getLocatorValue();
        String buildVersion = config.getHybridBuildVersion();
        List<LocatorCandidate> candidates = healingEngine.findBestCandidates(locatorId, context, buildVersion);

        int attemptBudget = Math.min(config.getHybridRetryCount(), candidates.size());
        for (int i = 0; i < attemptBudget; i++) {
            LocatorCandidate candidate = candidates.get(i);
            try {
                WebElement element = driver.findElement(candidate.getLocator());
                healingEngine.learnFromSuccess(locatorId, candidate, context, buildVersion);
                long elapsed = System.currentTimeMillis() - start;
                result.getLayer5Attempt().markSuccess(candidate.getLocator(), candidate.getFinalScore(), elapsed, "hybrid-intelligence");
                result.markOverallSuccess(candidate.getLocator(), HealingResult.HealingLayer.LAYER_5_HYBRID_INTELLIGENCE,
                    candidate.getFinalScore(), "hybrid-intelligence");
                return element;
            } catch (StaleElementReferenceException stale) {
                try {
                    WebElement retry = driver.findElement(candidate.getLocator());
                    healingEngine.learnFromSuccess(locatorId, candidate, context, buildVersion);
                    return retry;
                } catch (Exception ignored) {
                    // Continue to next candidate.
                }
            } catch (Exception ignored) {
                // Continue.
            }
        }

        healingEngine.learnFromFailure(locatorId, context, buildVersion, context.getExceptionMessage());
        long elapsed = System.currentTimeMillis() - start;
        result.getLayer5Attempt().markFailed(elapsed, "Hybrid candidates exhausted");
        log.debug("Hybrid intelligence failed for {}", locatorId);
        return null;
    }

    @Override
    public String getLayerName() {
        return "Layer 5 - Hybrid Intelligence";
    }

    @Override
    public boolean isEnabled() {
        return config.isHybridLayerEnabled();
    }

    @Override
    public int getLayerPriority() {
        return 5;
    }
}
