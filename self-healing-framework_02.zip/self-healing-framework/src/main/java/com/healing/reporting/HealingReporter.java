package com.healing.reporting;

import com.google.gson.*;
import com.healing.models.HealingResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

/**
 * Records healing events and generates a comprehensive HTML dashboard report.
 */
public class HealingReporter {

    private static final Logger log = LoggerFactory.getLogger(HealingReporter.class);
    private static final String REPORT_DIR = "target/healing-reports/";
    private final List<HealingResult> allResults = new CopyOnWriteArrayList<>();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public void recordSuccess(HealingResult result) {
        allResults.add(result);
        log.debug("Recorded healing success: {}", result.getSummary());
    }

    public void recordFailure(HealingResult result) {
        allResults.add(result);
        log.debug("Recorded healing failure: {}", result.getSummary());
    }

    /**
     * Generate HTML dashboard + JSON report after test suite finishes.
     */
    public void generateReport() {
        try {
            Files.createDirectories(Paths.get(REPORT_DIR));
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));

            generateJsonReport(timestamp);
            generateHtmlDashboard(timestamp);

            log.info("╔═══════════════════════════════════════╗");
            log.info("║  Healing Reports Generated            ║");
            log.info("║  HTML: {}/healing-dashboard-{}.html", REPORT_DIR, timestamp);
            log.info("║  JSON: {}/healing-report-{}.json", REPORT_DIR, timestamp);
            log.info("╚═══════════════════════════════════════╝");

        } catch (Exception e) {
            log.error("Failed to generate healing report: {}", e.getMessage());
        }
    }

    // ── Statistics ─────────────────────────────────────────────────────────

    public Map<String, Object> computeStats() {
        Map<String, Object> stats = new LinkedHashMap<>();
        int total = allResults.size();
        long successes = allResults.stream().filter(HealingResult::isSuccess).count();
        long failures = total - successes;

        stats.put("total", total);
        stats.put("successes", successes);
        stats.put("failures", failures);
        stats.put("successRate", total > 0 ? (double) successes / total : 0.0);

        // Per-layer breakdown
        Map<String, Long> layerBreakdown = new LinkedHashMap<>();
        for (HealingResult.HealingLayer layer : HealingResult.HealingLayer.values()) {
            long count = allResults.stream()
                    .filter(r -> r.isSuccess() && layer.equals(r.getSuccessLayer()))
                    .count();
            if (layer.getLayerNumber() > 0) layerBreakdown.put(layer.getDisplayName(), count);
        }
        stats.put("layerBreakdown", layerBreakdown);

        // Average confidence
        double avgConf = allResults.stream()
                .filter(HealingResult::isSuccess)
                .mapToDouble(HealingResult::getConfidenceScore)
                .average().orElse(0.0);
        stats.put("avgConfidence", avgConf);

        return stats;
    }

    // ── JSON Report ─────────────────────────────────────────────────────────

    private void generateJsonReport(String timestamp) throws IOException {
        Map<String, Object> report = new LinkedHashMap<>();
        report.put("generatedAt", LocalDateTime.now().toString());
        report.put("stats", computeStats());
        report.put("results", allResults.stream().map(this::resultToMap).collect(Collectors.toList()));

        String json = gson.toJson(report);
        Files.write(Paths.get(REPORT_DIR + "healing-report-" + timestamp + ".json"),
                json.getBytes());
    }

    private Map<String, Object> resultToMap(HealingResult r) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("originalLocator", r.getOriginalLocator() != null ? r.getOriginalLocator().toString() : "?");
        m.put("status", r.getStatus().name());
        m.put("successLayer", r.getSuccessLayer() != null ? r.getSuccessLayer().getDisplayName() : null);
        m.put("strategy", r.getHealingStrategy());
        m.put("confidence", r.getConfidenceScore());
        m.put("healingTimeMs", r.getHealingTimeMs());
        m.put("healedLocator", r.getHealedLocator() != null ? r.getHealedLocator().toString() : null);
        m.put("timestamp", r.getTimestamp() != null ? r.getTimestamp().toString() : null);
        return m;
    }

    // ── HTML Dashboard ─────────────────────────────────────────────────────

    private void generateHtmlDashboard(String timestamp) throws IOException {
        Map<String, Object> stats = computeStats();
        int total = (int) stats.get("total");
        long successes = (long) stats.get("successes");
        long failures = (long) stats.get("failures");
        double successRate = (double) stats.get("successRate");
        @SuppressWarnings("unchecked")
        Map<String, Long> layerBreakdown = (Map<String, Long>) stats.get("layerBreakdown");

        String layerRows = layerBreakdown.entrySet().stream()
                .map(e -> String.format("<tr><td>%s</td><td>%d</td><td>%.1f%%</td></tr>",
                        e.getKey(), e.getValue(),
                        total > 0 ? 100.0 * e.getValue() / total : 0.0))
                .collect(Collectors.joining("\n"));

        String resultRows = allResults.stream().map(r -> {
            String status = r.isSuccess() ? "✅ Healed" : "❌ Failed";
            String statusClass = r.isSuccess() ? "success" : "failure";
            String layer = r.getSuccessLayer() != null ? r.getSuccessLayer().getDisplayName() : "—";
            String strategy = r.getHealingStrategy() != null ? r.getHealingStrategy() : "—";
            String orig = r.getOriginalLocator() != null ? escapeHtml(r.getOriginalLocator().toString()) : "?";
            return String.format(
                "<tr class='%s'><td>%s</td><td class='locator'>%s</td><td>%s</td><td>%s</td><td>%.2f</td><td>%dms</td></tr>",
                statusClass, status, orig, layer, strategy, r.getConfidenceScore(), r.getHealingTimeMs());
        }).collect(Collectors.joining("\n"));

        String html = "<!DOCTYPE html>\n<html lang='en'>\n<head>\n" +
            "<meta charset='UTF-8'>\n" +
            "<meta name='viewport' content='width=device-width, initial-scale=1.0'>\n" +
            "<title>Self-Healing Framework Dashboard</title>\n" +
            "<style>\n" +
            "  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; margin:0; background:#0f1117; color:#e0e0e0; }\n" +
            "  .header { background: linear-gradient(135deg,#1a1f2e,#252b3b); padding:24px 32px; border-bottom:1px solid #2d3748; }\n" +
            "  .header h1 { margin:0; font-size:1.8rem; color:#7dd3fc; }\n" +
            "  .header p { margin:4px 0 0; color:#94a3b8; font-size:0.9rem; }\n" +
            "  .container { max-width:1200px; margin:0 auto; padding:24px 32px; }\n" +
            "  .cards { display:grid; grid-template-columns:repeat(4,1fr); gap:16px; margin-bottom:24px; }\n" +
            "  .card { background:#1e2533; border-radius:12px; padding:20px; border:1px solid #2d3748; }\n" +
            "  .card .label { font-size:0.8rem; color:#64748b; text-transform:uppercase; letter-spacing:.05em; }\n" +
            "  .card .value { font-size:2.2rem; font-weight:700; margin:8px 0 0; }\n" +
            "  .card.green .value { color:#34d399; } .card.red .value { color:#f87171; }\n" +
            "  .card.blue .value { color:#60a5fa; } .card.purple .value { color:#a78bfa; }\n" +
            "  .section { background:#1e2533; border-radius:12px; padding:20px; border:1px solid #2d3748; margin-bottom:20px; }\n" +
            "  .section h2 { margin:0 0 16px; font-size:1.1rem; color:#94a3b8; }\n" +
            "  table { width:100%; border-collapse:collapse; font-size:0.85rem; }\n" +
            "  th { background:#252b3b; color:#64748b; padding:10px 12px; text-align:left; font-weight:600; }\n" +
            "  td { padding:10px 12px; border-bottom:1px solid #1a1f2e; vertical-align:top; }\n" +
            "  tr.success td { color:#d1fae5; } tr.failure td { color:#fee2e2; }\n" +
            "  .locator { font-family:monospace; font-size:0.78rem; word-break:break-all; max-width:300px; }\n" +
            "  .badge { display:inline-block; padding:2px 8px; border-radius:9999px; font-size:0.75rem; font-weight:600; }\n" +
            "  .layer-table td:first-child { font-weight:500; }\n" +
            "  .progress { background:#252b3b; border-radius:9999px; height:8px; margin-top:4px; }\n" +
            "  .progress-bar { background: linear-gradient(90deg,#34d399,#60a5fa); border-radius:9999px; height:8px; }\n" +
            "</style>\n</head>\n<body>\n" +
            "<div class='header'>\n" +
            "  <h1>🔮 Self-Healing Framework Dashboard</h1>\n" +
            "  <p>Generated: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + " | 4-Layer Architecture</p>\n" +
            "</div>\n<div class='container'>\n" +
            "<div class='cards'>\n" +
            "  <div class='card blue'><div class='label'>Total Heals Attempted</div><div class='value'>" + total + "</div></div>\n" +
            "  <div class='card green'><div class='label'>Successful Heals</div><div class='value'>" + successes + "</div></div>\n" +
            "  <div class='card red'><div class='label'>Failed Heals</div><div class='value'>" + failures + "</div></div>\n" +
            "  <div class='card purple'><div class='label'>Success Rate</div><div class='value'>" + String.format("%.1f%%", successRate * 100) + "</div></div>\n" +
            "</div>\n" +
            "<div class='section'>\n" +
            "  <h2>Layer Breakdown</h2>\n" +
            "  <table class='layer-table'><tr><th>Layer</th><th>Heals</th><th>% of Total</th></tr>\n" +
            layerRows + "\n</table>\n</div>\n" +
            "<div class='section'>\n" +
            "  <h2>Healing Event Log</h2>\n" +
            "  <table><tr><th>Status</th><th>Original Locator</th><th>Healed By Layer</th><th>Strategy</th><th>Confidence</th><th>Time</th></tr>\n" +
            resultRows + "\n</table>\n</div>\n" +
            "<div class='section'>\n" +
            "  <h2>Architecture Overview</h2>\n" +
            "  <table><tr><th>Layer</th><th>Approach</th><th>Strategies</th><th>Speed</th><th>Target Rate</th></tr>\n" +
            "  <tr><td>Layer 1</td><td>Cache &amp; Quick Rules</td><td>Cache, case, attr-swap, partial-match</td><td>~100ms</td><td>20-25%</td></tr>\n" +
            "  <tr><td>Layer 2</td><td>Healenium ML Engine</td><td>LCS, Tree Edit Distance, Weighted Score</td><td>2-5s</td><td>55-65%</td></tr>\n" +
            "  <tr><td>Layer 3</td><td>Advanced Fallback</td><td>Text search, Fuzzy LCS, Hierarchy, XPath simplify</td><td>1-4s</td><td>15-22%</td></tr>\n" +
            "  <tr><td>Layer 4</td><td>Claude AI LLM</td><td>Full DOM context → Claude → 5 candidates</td><td>3-15s</td><td>60-80%*</td></tr>\n" +
            "  </table>\n  <p style='color:#64748b;font-size:0.8rem'>* Layer 4 rate is of cases that reach it; overall system target: 90%+</p>\n" +
            "</div>\n</div>\n</body>\n</html>";

        Files.write(Paths.get(REPORT_DIR + "healing-dashboard-" + timestamp + ".html"),
                html.getBytes());
    }

    private String escapeHtml(String s) {
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("'","&#39;");
    }
}
