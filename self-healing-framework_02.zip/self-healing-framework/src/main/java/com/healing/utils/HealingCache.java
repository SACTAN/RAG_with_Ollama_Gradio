package com.healing.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Thread-safe healing cache that stores healed locators.
 * Persists to JSON file so cache survives test runs.
 *
 * Cache Key = locatorType + ":" + locatorValue  (normalized)
 */
public class HealingCache {

    private static final Logger log = LoggerFactory.getLogger(HealingCache.class);
    private static final String CACHE_FILE = "target/healing-reports/healing-cache.json";
    private static HealingCache instance;

    private final Map<String, CacheEntry> cache = new ConcurrentHashMap<>();
    private final int maxSize;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    private HealingCache(int maxSize) {
        this.maxSize = maxSize;
        loadFromFile();
    }

    public static synchronized HealingCache getInstance(int maxSize) {
        if (instance == null) instance = new HealingCache(maxSize);
        return instance;
    }

    /**
     * Look up a healed locator for a failed one.
     * Returns null if not found or expired.
     */
    public String lookup(String locatorType, String locatorValue) {
        String key = buildKey(locatorType, locatorValue);
        CacheEntry entry = cache.get(key);
        if (entry != null) {
            entry.incrementHits();
            log.debug("Cache HIT for key: {}", key);
            return entry.getHealedLocator();
        }
        log.debug("Cache MISS for key: {}", key);
        return null;
    }

    /**
     * Store a successful healing result.
     */
    public void store(String originalType, String originalValue,
                      String healedLocatorStr, String strategy, double confidence) {
        if (cache.size() >= maxSize) {
            evictLeastUsed();
        }
        String key = buildKey(originalType, originalValue);
        CacheEntry entry = new CacheEntry(key, healedLocatorStr, strategy, confidence);
        cache.put(key, entry);
        log.debug("Cached healing: {} → {} [{}]", key, healedLocatorStr, strategy);
        persistToFile();
    }

    /**
     * Mark a cached entry as invalid (was tried but failed).
     */
    public void invalidate(String locatorType, String locatorValue) {
        String key = buildKey(locatorType, locatorValue);
        cache.remove(key);
        log.debug("Invalidated cache entry: {}", key);
    }

    public int size() { return cache.size(); }

    public void clear() {
        cache.clear();
        persistToFile();
    }

    // ---- Private helpers ----

    private String buildKey(String type, String value) {
        return (type + ":" + value).toLowerCase().trim();
    }

    private void evictLeastUsed() {
        cache.entrySet().stream()
                .min(Comparator.comparingInt(e -> e.getValue().getHitCount()))
                .ifPresent(e -> {
                    log.debug("Evicting LRU cache entry: {}", e.getKey());
                    cache.remove(e.getKey());
                });
    }

    private void persistToFile() {
        try {
            Path path = Paths.get(CACHE_FILE);
            Files.createDirectories(path.getParent());
            Files.write(path, gson.toJson(cache.values()).getBytes());
        } catch (IOException e) {
            log.warn("Failed to persist cache: {}", e.getMessage());
        }
    }

    private void loadFromFile() {
        try {
            Path path = Paths.get(CACHE_FILE);
            if (Files.exists(path)) {
                String json = new String(Files.readAllBytes(path));
                Type listType = new TypeToken<List<CacheEntry>>(){}.getType();
                List<CacheEntry> entries = gson.fromJson(json, listType);
                if (entries != null) {
                    entries.forEach(e -> cache.put(e.getKey(), e));
                    log.info("Loaded {} entries from healing cache", cache.size());
                }
            }
        } catch (Exception e) {
            log.warn("Could not load cache from file: {}", e.getMessage());
        }
    }

    // ---- Cache Entry ----
    public static class CacheEntry {
        private final String key;
        private final String healedLocator;
        private final String strategy;
        private final double confidence;
        private final String createdAt;
        private int hitCount;

        public CacheEntry(String key, String healedLocator, String strategy, double confidence) {
            this.key = key;
            this.healedLocator = healedLocator;
            this.strategy = strategy;
            this.confidence = confidence;
            this.createdAt = LocalDateTime.now().toString();
            this.hitCount = 0;
        }

        public void incrementHits() { this.hitCount++; }
        public String getKey() { return key; }
        public String getHealedLocator() { return healedLocator; }
        public String getStrategy() { return strategy; }
        public double getConfidence() { return confidence; }
        public int getHitCount() { return hitCount; }
    }
}
