package com.healing.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Centralized configuration for the 4-layer self-healing framework.
 * Reads from healing-config.properties with sensible defaults.
 */
public class HealingConfig {

    private static final Logger log = LoggerFactory.getLogger(HealingConfig.class);
    private static final String CONFIG_FILE = "healing-config.properties";
    private static HealingConfig instance;
    private final Properties props = new Properties();

    private HealingConfig() {
        loadProperties();
    }

    public static synchronized HealingConfig getInstance() {
        if (instance == null) {
            instance = new HealingConfig();
        }
        return instance;
    }

    private void loadProperties() {
        try (InputStream is = getClass().getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            if (is != null) {
                props.load(is);
                log.info("Loaded healing config from {}", CONFIG_FILE);
            } else {
                log.warn("healing-config.properties not found; using defaults");
            }
        } catch (IOException e) {
            log.error("Error loading healing config: {}", e.getMessage());
        }
        // Override with system properties
        props.putAll(System.getProperties());
    }

    // ===== GLOBAL =====
    public boolean isHealingEnabled() {
        return Boolean.parseBoolean(props.getProperty("healing.enabled", "true"));
    }

    // ===== LAYER 1 - Cache & Quick Rules =====
    public boolean isLayer1Enabled() {
        return Boolean.parseBoolean(props.getProperty("healing.layer1.enabled", "true"));
    }
    public long getLayer1TimeoutMs() {
        return Long.parseLong(props.getProperty("healing.layer1.timeout.ms", "150"));
    }
    public boolean isCacheEnabled() {
        return Boolean.parseBoolean(props.getProperty("healing.layer1.cache.enabled", "true"));
    }
    public int getCacheMaxSize() {
        return Integer.parseInt(props.getProperty("healing.layer1.cache.maxSize", "500"));
    }

    // ===== LAYER 2 - Healenium ML =====
    public boolean isLayer2Enabled() {
        return Boolean.parseBoolean(props.getProperty("healing.layer2.enabled", "true"));
    }
    public long getLayer2TimeoutMs() {
        return Long.parseLong(props.getProperty("healing.layer2.timeout.ms", "7000"));
    }
    public String getHealeniumHost() {
        return props.getProperty("healenium.server.host", "localhost");
    }
    public int getHealeniumPort() {
        return Integer.parseInt(props.getProperty("healenium.server.port", "7878"));
    }
    public double getHealeniumScoreCap() {
        return Double.parseDouble(props.getProperty("healenium.score-cap", "0.6"));
    }
    public int getHealeniumRecoveryTries() {
        return Integer.parseInt(props.getProperty("healenium.recovery-tries", "5"));
    }

    // ===== LAYER 3 - Advanced Fallback =====
    public boolean isLayer3Enabled() {
        return Boolean.parseBoolean(props.getProperty("healing.layer3.enabled", "true"));
    }
    public long getLayer3TimeoutMs() {
        return Long.parseLong(props.getProperty("healing.layer3.timeout.ms", "4000"));
    }
    public double getLayer3ScoreThreshold() {
        return Double.parseDouble(props.getProperty("healing.layer3.score.threshold", "0.6"));
    }
    public double getWeightText() {
        return Double.parseDouble(props.getProperty("healing.score.weight.text", "0.45"));
    }
    public double getWeightAttribute() {
        return Double.parseDouble(props.getProperty("healing.score.weight.attribute", "0.25"));
    }
    public double getWeightClass() {
        return Double.parseDouble(props.getProperty("healing.score.weight.class", "0.20"));
    }
    public double getWeightPosition() {
        return Double.parseDouble(props.getProperty("healing.score.weight.position", "0.10"));
    }

    // ===== LAYER 4 - LLM AI =====
    public boolean isLayer4Enabled() {
        return Boolean.parseBoolean(props.getProperty("healing.layer4.enabled", "true"));
    }
    public String getLlmApiKey() {
        // Prefer env var for security
        String envKey = System.getenv("ANTHROPIC_API_KEY");
        return envKey != null ? envKey : props.getProperty("healing.layer4.llm.apiKey", "");
    }
    public String getLlmModel() {
        return props.getProperty("healing.layer4.llm.model", "claude-sonnet-4-20250514");
    }
    public String getLlmApiUrl() {
        return props.getProperty("healing.layer4.llm.apiUrl",
                "https://api.anthropic.com/v1/messages");
    }
    public int getLlmMaxTokens() {
        return Integer.parseInt(props.getProperty("healing.layer4.llm.maxTokens", "1000"));
    }
    public long getLlmTimeoutMs() {
        return Long.parseLong(props.getProperty("healing.layer4.llm.timeout.ms", "15000"));
    }
    public int getLlmMaxRetries() {
        return Integer.parseInt(props.getProperty("healing.layer4.llm.maxRetries", "2"));
    }

    // ===== LAYER 5 - Hybrid Intelligence =====
    public boolean isHybridLayerEnabled() {
        return Boolean.parseBoolean(props.getProperty("healing.hybrid.enabled", "true"));
    }
    public String getHybridBuildVersion() {
        return props.getProperty("healing.hybrid.build.version", "local");
    }
    public int getHybridRetryCount() {
        return Integer.parseInt(props.getProperty("healing.hybrid.retry.count", "3"));
    }
    public int getHybridTopK() {
        return Integer.parseInt(props.getProperty("healing.hybrid.vector.topk", "10"));
    }
    public double getHybridGraphThreshold() {
        return Double.parseDouble(props.getProperty("healing.hybrid.graph.threshold", "0.70"));
    }
    public String getHybridNeo4jUri() {
        return props.getProperty("healing.hybrid.neo4j.uri", "bolt://localhost:7687");
    }
    public String getHybridNeo4jUser() {
        return props.getProperty("healing.hybrid.neo4j.user", "neo4j");
    }
    public String getHybridNeo4jPassword() {
        return props.getProperty("healing.hybrid.neo4j.password", "password");
    }
    public String getHybridEmbeddingModel() {
        return props.getProperty("healing.hybrid.embedding.model", "sentence-transformers/all-MiniLM-L6-v2");
    }
    public String getHybridVectorJdbcUrl() {
        return props.getProperty("healing.hybrid.vector.jdbc.url", "jdbc:h2:mem:healing_vectors;DB_CLOSE_DELAY=-1");
    }
    public String getHybridVectorJdbcUser() {
        return props.getProperty("healing.hybrid.vector.jdbc.user", "sa");
    }
    public String getHybridVectorJdbcPassword() {
        return props.getProperty("healing.hybrid.vector.jdbc.password", "");
    }
    public String getHybridProjectId() {
        return props.getProperty("healing.hybrid.tenant.projectId", "default-project");
    }
    public String getHybridEnv() {
        return props.getProperty("healing.hybrid.tenant.env", "default-env");
    }

    // ===== REPORTING =====
    public boolean isReportingEnabled() {
        return Boolean.parseBoolean(props.getProperty("healing.report.enabled", "true"));
    }
    public String getReportOutputPath() {
        return props.getProperty("healing.report.output.path", "target/healing-reports/");
    }
    public boolean isDashboardEnabled() {
        return Boolean.parseBoolean(props.getProperty("healing.dashboard.enabled", "true"));
    }

    public String get(String key, String defaultValue) {
        return props.getProperty(key, defaultValue);
    }
}
