package com.healing.core;

import com.healing.config.HealingConfig;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Interactive;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.*;

/**
 * =====================================================================
 * SELF-HEALING WEB DRIVER
 * =====================================================================
 *
 * Wraps any WebDriver and intercepts findElement/findElements calls.
 * On NoSuchElementException, automatically invokes the 4-layer
 * HybridHealingCoordinator.
 *
 * Usage:
 *   WebDriver driver = SelfHealingWebDriver.wrap(new ChromeDriver());
 *   // Or use factory:
 *   WebDriver driver = SelfHealingWebDriver.create(ChromeDriver.class);
 *
 * Then use driver exactly like a normal WebDriver — healing is transparent!
 *
 *   driver.findElement(By.id("submit-btn"));  // If this fails → auto-heal
 */
public class SelfHealingWebDriver implements WebDriver, TakesScreenshot, JavascriptExecutor {

    private static final Logger log = LoggerFactory.getLogger(SelfHealingWebDriver.class);

    private final WebDriver delegate;
    private final HybridHealingCoordinator coordinator;
    private final HealingConfig config;
    private final Map<String, By> smartLocatorRegistry = new HashMap<>();

    // Explicit wait settings
    private Duration implicitWait = Duration.ofSeconds(0);
    private static final Duration RETRY_WAIT = Duration.ofMillis(500);

    private SelfHealingWebDriver(WebDriver delegate) {
        this.delegate = Objects.requireNonNull(delegate, "WebDriver delegate cannot be null");
        this.coordinator = new HybridHealingCoordinator();
        this.config = HealingConfig.getInstance();
    }

    /**
     * Factory method — wrap any existing WebDriver.
     */
    public static SelfHealingWebDriver wrap(WebDriver driver) {
        return new SelfHealingWebDriver(driver);
    }

    public void registerSmartLocator(String locatorId, By locator) {
        smartLocatorRegistry.put(locatorId, locator);
    }

    public WebElement findElementSmart(String locatorId) {
        By by = smartLocatorRegistry.get(locatorId);
        if (by == null) {
            by = By.id(locatorId);
        }
        return findElement(by);
    }

    // ── Core Healing Override ──────────────────────────────────────────────

    /**
     * Finds element. On failure, triggers 4-layer self-healing.
     */
    @Override
    public WebElement findElement(By by) {
        try {
            // First attempt — normal find
            return delegate.findElement(by);

        } catch (org.openqa.selenium.NoSuchElementException | StaleElementReferenceException e) {

            if (!config.isHealingEnabled()) {
                log.debug("Healing disabled — re-throwing {}", e.getClass().getSimpleName());
                throw e;
            }

            log.info("🔴 Element not found with [{}]. Activating self-healing...", by);

            // Invoke the 4-layer healing coordinator
            WebElement healed = coordinator.heal(by, e, delegate);
            if (healed != null) {
                return healed;
            }
            throw e;
        }
    }

    /**
     * Finds all elements. If none found, attempts healing and retries.
     */
    @Override
    public List<WebElement> findElements(By by) {
        List<WebElement> elements = delegate.findElements(by);
        if (!elements.isEmpty()) return elements;

        if (!config.isHealingEnabled()) return elements;

        log.info("🔴 findElements returned empty for [{}]. Attempting healing...", by);
        try {
            WebElement healed = coordinator.heal(by,
                    new org.openqa.selenium.NoSuchElementException("findElements returned empty: " + by),
                    delegate);
            if (healed != null) return Collections.singletonList(healed);
        } catch (Exception e) {
            log.debug("Healing also failed for findElements: {}", e.getMessage());
        }
        return Collections.emptyList();
    }

    // ── Convenience Smart Click / Type ────────────────────────────────────

    /**
     * Click with built-in healing and retry.
     */
    public void click(By by) {
        findElement(by).click();
    }

    /**
     * Type text with healing.
     */
    public void type(By by, String text) {
        WebElement el = findElement(by);
        el.clear();
        el.sendKeys(text);
    }

    /**
     * Get visible text with healing.
     */
    public String getText(By by) {
        return findElement(by).getText();
    }

    /**
     * Wait for element to be visible, then return it (with healing).
     */
    public WebElement waitAndFind(By by, int timeoutSeconds) {
        try {
            WebDriverWait wait = new WebDriverWait(delegate, Duration.ofSeconds(timeoutSeconds));
            return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
        } catch (Exception e) {
            log.info("waitAndFind: Element not visible in {}s, triggering healing for: {}", timeoutSeconds, by);
            return coordinator.heal(by, e, delegate);
        }
    }

    /**
     * Check if element is present (no healing — just boolean).
     */
    public boolean isPresent(By by) {
        return !delegate.findElements(by).isEmpty();
    }

    // ── Delegate all other WebDriver methods ──────────────────────────────

    @Override public void get(String url) { delegate.get(url); }
    @Override public String getCurrentUrl() { return delegate.getCurrentUrl(); }
    @Override public String getTitle() { return delegate.getTitle(); }
    @Override public String getPageSource() { return delegate.getPageSource(); }
    @Override public void close() { delegate.close(); }
    @Override public void quit() { delegate.quit(); }
    @Override public Set<String> getWindowHandles() { return delegate.getWindowHandles(); }
    @Override public String getWindowHandle() { return delegate.getWindowHandle(); }
    @Override public TargetLocator switchTo() { return delegate.switchTo(); }
    @Override public Navigation navigate() { return delegate.navigate(); }
    @Override public Options manage() { return delegate.manage(); }

    // ── JavaScript + Screenshots ──────────────────────────────────────────

    @Override
    public Object executeScript(String script, Object... args) {
        return ((JavascriptExecutor) delegate).executeScript(script, args);
    }

    @Override
    public Object executeAsyncScript(String script, Object... args) {
        return ((JavascriptExecutor) delegate).executeAsyncScript(script, args);
    }

    @Override
    public <X> X getScreenshotAs(OutputType<X> target) throws WebDriverException {
        return ((TakesScreenshot) delegate).getScreenshotAs(target);
    }

    /**
     * Access the underlying unwrapped WebDriver.
     */
    public WebDriver getDelegate() { return delegate; }
}
