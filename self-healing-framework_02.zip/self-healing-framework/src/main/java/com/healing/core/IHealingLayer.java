package com.healing.core;

import com.healing.models.ElementContext;
import com.healing.models.HealingResult;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Contract for every healing layer in the 4-layer framework.
 *
 * Execution Order:
 *   Layer 1 → Layer 2 → Layer 3 → Layer 4
 *
 * Each layer should:
 *  1. Attempt to find/heal the element
 *  2. Return a HealingResult indicating success or failure
 *  3. NOT throw exceptions (catch and encapsulate in HealingResult)
 */
public interface IHealingLayer {

    /**
     * Attempt to heal the failed element.
     *
     * @param context   Full context of the failed element
     * @param driver    Active WebDriver session
     * @param result    HealingResult to populate with this layer's attempt
     * @return          The healed WebElement if found, null otherwise
     */
    WebElement attemptHealing(ElementContext context, WebDriver driver, HealingResult result);

    /**
     * Human-readable name of this healing layer.
     */
    String getLayerName();

    /**
     * Whether this layer is enabled via configuration.
     */
    boolean isEnabled();

    /**
     * Layer priority number (lower = tried first).
     */
    int getLayerPriority();
}
