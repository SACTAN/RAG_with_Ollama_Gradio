package com.healing.core;

import com.healing.reporting.HealingReporter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.*;

/**
 * TestNG Listener that auto-generates healing reports after suite completion.
 * Add to your testng.xml: <listener class-name="com.healing.core.HealingTestListener"/>
 */
public class HealingTestListener implements ISuiteListener, ITestListener {

    private static final Logger log = LoggerFactory.getLogger(HealingTestListener.class);
    private static final HealingReporter REPORTER = new HealingReporter();

    @Override
    public void onFinish(ISuite suite) {
        log.info("Test suite finished. Generating self-healing report...");
        REPORTER.generateReport();
    }

    @Override
    public void onTestFailure(ITestResult result) {
        log.debug("Test FAILED: {}", result.getName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        log.debug("Test PASSED: {}", result.getName());
    }

    @Override public void onStart(ISuite suite) {}
    @Override public void onTestStart(ITestResult result) {}
    @Override public void onTestSkipped(ITestResult result) {}
    @Override public void onTestFailedButWithinSuccessPercentage(ITestResult result) {}
    @Override public void onStart(ITestContext context) {}
    @Override public void onFinish(ITestContext context) {}
}
