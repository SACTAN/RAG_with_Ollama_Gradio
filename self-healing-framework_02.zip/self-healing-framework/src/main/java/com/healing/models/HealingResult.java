package com.healing.models;

import org.openqa.selenium.By;
import java.time.LocalDateTime;

/**
 * Encapsulates the result of a self-healing attempt across all layers.
 */
public class HealingResult {

    public enum Status {
        SUCCESS,
        FAILED,
        NOT_ATTEMPTED
    }

    public enum HealingLayer {
        LAYER_1_CACHE_RULES("Layer 1 - Cache & Quick Rules", 1),
        LAYER_2_HEALENIUM_ML("Layer 2 - Healenium ML Engine", 2),
        LAYER_3_ADVANCED_FALLBACK("Layer 3 - Advanced Fallback", 3),
        LAYER_4_LLM_AI("Layer 4 - LLM AI (Claude)", 4),
        LAYER_5_HYBRID_INTELLIGENCE("Layer 5 - Hybrid Intelligence", 5),
        ORIGINAL("Original Locator", 0);

        private final String displayName;
        private final int layerNumber;

        HealingLayer(String displayName, int layerNumber) {
            this.displayName = displayName;
            this.layerNumber = layerNumber;
        }

        public String getDisplayName() { return displayName; }
        public int getLayerNumber() { return layerNumber; }
    }

    // ---- Fields ----
    private final By originalLocator;
    private By healedLocator;
    private Status status;
    private HealingLayer successLayer;
    private double confidenceScore;
    private long healingTimeMs;
    private String failureReason;
    private String healingStrategy;
    private LocalDateTime timestamp;

    // Layer-by-layer results
    private LayerAttempt layer1Attempt = new LayerAttempt(HealingLayer.LAYER_1_CACHE_RULES);
    private LayerAttempt layer2Attempt = new LayerAttempt(HealingLayer.LAYER_2_HEALENIUM_ML);
    private LayerAttempt layer3Attempt = new LayerAttempt(HealingLayer.LAYER_3_ADVANCED_FALLBACK);
    private LayerAttempt layer4Attempt = new LayerAttempt(HealingLayer.LAYER_4_LLM_AI);
    private LayerAttempt layer5Attempt = new LayerAttempt(HealingLayer.LAYER_5_HYBRID_INTELLIGENCE);

    public HealingResult(By originalLocator) {
        this.originalLocator = originalLocator;
        this.status = Status.NOT_ATTEMPTED;
        this.timestamp = LocalDateTime.now();
    }

    // ---- Inner class for per-layer tracking ----
    public static class LayerAttempt {
        private final HealingLayer layer;
        private Status status = Status.NOT_ATTEMPTED;
        private By resultLocator;
        private double score;
        private long durationMs;
        private String strategyUsed;
        private String errorMessage;

        public LayerAttempt(HealingLayer layer) { this.layer = layer; }

        public void markSuccess(By locator, double score, long durationMs, String strategy) {
            this.status = Status.SUCCESS;
            this.resultLocator = locator;
            this.score = score;
            this.durationMs = durationMs;
            this.strategyUsed = strategy;
        }

        public void markFailed(long durationMs, String error) {
            this.status = Status.FAILED;
            this.durationMs = durationMs;
            this.errorMessage = error;
        }

        // Getters
        public HealingLayer getLayer() { return layer; }
        public Status getStatus() { return status; }
        public By getResultLocator() { return resultLocator; }
        public double getScore() { return score; }
        public long getDurationMs() { return durationMs; }
        public String getStrategyUsed() { return strategyUsed; }
        public String getErrorMessage() { return errorMessage; }
    }

    // ---- Convenience methods ----
    public void markOverallSuccess(By healedLocator, HealingLayer layer, double score, String strategy) {
        this.status = Status.SUCCESS;
        this.healedLocator = healedLocator;
        this.successLayer = layer;
        this.confidenceScore = score;
        this.healingStrategy = strategy;
    }

    public void markOverallFailed(String reason) {
        this.status = Status.FAILED;
        this.failureReason = reason;
    }

    public boolean isSuccess() { return status == Status.SUCCESS; }

    public String getSummary() {
        if (status == Status.SUCCESS) {
            return String.format("[HEALED] Original: %s → Healed: %s | Layer: %s | Score: %.2f | Strategy: %s",
                    originalLocator, healedLocator, successLayer.getDisplayName(), confidenceScore, healingStrategy);
        } else {
            return String.format("[FAILED] Original: %s | Reason: %s", originalLocator, failureReason);
        }
    }

    // --- Getters ---
    public By getOriginalLocator() { return originalLocator; }
    public By getHealedLocator() { return healedLocator; }
    public Status getStatus() { return status; }
    public HealingLayer getSuccessLayer() { return successLayer; }
    public double getConfidenceScore() { return confidenceScore; }
    public long getHealingTimeMs() { return healingTimeMs; }
    public void setHealingTimeMs(long healingTimeMs) { this.healingTimeMs = healingTimeMs; }
    public String getHealingStrategy() { return healingStrategy; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public LayerAttempt getLayer1Attempt() { return layer1Attempt; }
    public LayerAttempt getLayer2Attempt() { return layer2Attempt; }
    public LayerAttempt getLayer3Attempt() { return layer3Attempt; }
    public LayerAttempt getLayer4Attempt() { return layer4Attempt; }
    public LayerAttempt getLayer5Attempt() { return layer5Attempt; }
}
