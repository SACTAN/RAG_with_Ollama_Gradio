package com.healing.models;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.util.List;
import java.util.Map;

/**
 * Captures full context of a failed element for healing.
 * Used by all layers to understand what element to find.
 */
public class ElementContext {

    private final By originalLocator;
    private final String locatorType;   // "id", "xpath", "css", "name", etc.
    private final String locatorValue;

    // DOM context
    private String pageSource;
    private String pageTitle;
    private String pageUrl;

    // Element metadata (if partially found)
    private String tagName;
    private String innerText;
    private Map<String, String> attributes;
    private String parentXPath;
    private List<String> siblingTexts;
    private int domDepth;

    // Screenshot (base64 for LLM vision)
    private String screenshotBase64;

    // Failure info
    private String exceptionMessage;
    private int failureCount;

    public ElementContext(By originalLocator) {
        this.originalLocator = originalLocator;
        this.locatorType = extractLocatorType(originalLocator);
        this.locatorValue = extractLocatorValue(originalLocator);
    }

    private String extractLocatorType(By locator) {
        if (locator == null) return "unknown";
        String str = locator.toString();
        if (str.contains("By.id:")) return "id";
        if (str.contains("By.cssSelector:")) return "css";
        if (str.contains("By.xpath:")) return "xpath";
        if (str.contains("By.name:")) return "name";
        if (str.contains("By.className:")) return "className";
        if (str.contains("By.tagName:")) return "tagName";
        if (str.contains("By.linkText:")) return "linkText";
        if (str.contains("By.partialLinkText:")) return "partialLinkText";
        return "unknown";
    }

    private String extractLocatorValue(By locator) {
        if (locator == null) return "";
        String str = locator.toString();
        int colonIdx = str.indexOf(": ");
        return colonIdx >= 0 ? str.substring(colonIdx + 2).trim() : str;
    }

    // ---- Builder-style setters ----
    public ElementContext withPageSource(String pageSource) {
        this.pageSource = pageSource;
        return this;
    }

    public ElementContext withPageTitle(String pageTitle) {
        this.pageTitle = pageTitle;
        return this;
    }

    public ElementContext withPageUrl(String pageUrl) {
        this.pageUrl = pageUrl;
        return this;
    }

    public ElementContext withTagName(String tagName) {
        this.tagName = tagName;
        return this;
    }

    public ElementContext withInnerText(String innerText) {
        this.innerText = innerText;
        return this;
    }

    public ElementContext withAttributes(Map<String, String> attributes) {
        this.attributes = attributes;
        return this;
    }

    public ElementContext withParentXPath(String parentXPath) {
        this.parentXPath = parentXPath;
        return this;
    }

    public ElementContext withSiblingTexts(List<String> siblingTexts) {
        this.siblingTexts = siblingTexts;
        return this;
    }

    public ElementContext withDomDepth(int domDepth) {
        this.domDepth = domDepth;
        return this;
    }

    public ElementContext withScreenshotBase64(String screenshotBase64) {
        this.screenshotBase64 = screenshotBase64;
        return this;
    }

    public ElementContext withExceptionMessage(String exceptionMessage) {
        this.exceptionMessage = exceptionMessage;
        return this;
    }

    public ElementContext withFailureCount(int failureCount) {
        this.failureCount = failureCount;
        return this;
    }

    // ---- Getters ----
    public By getOriginalLocator() { return originalLocator; }
    public String getLocatorType() { return locatorType; }
    public String getLocatorValue() { return locatorValue; }
    public String getPageSource() { return pageSource; }
    public String getPageTitle() { return pageTitle; }
    public String getPageUrl() { return pageUrl; }
    public String getTagName() { return tagName; }
    public String getInnerText() { return innerText; }
    public Map<String, String> getAttributes() { return attributes; }
    public String getParentXPath() { return parentXPath; }
    public List<String> getSiblingTexts() { return siblingTexts; }
    public int getDomDepth() { return domDepth; }
    public String getScreenshotBase64() { return screenshotBase64; }
    public String getExceptionMessage() { return exceptionMessage; }
    public int getFailureCount() { return failureCount; }

    /**
     * Returns a compact summary for logging.
     */
    public String toCompactString() {
        return String.format("ElementContext{type='%s', value='%s', tag='%s', text='%s'}",
                locatorType, locatorValue,
                tagName != null ? tagName : "?",
                innerText != null && innerText.length() > 50 ? innerText.substring(0, 50) + "..." : innerText);
    }
}
