package com.healing.intelligence.infrastructure.embedding;

import com.healing.intelligence.domain.DomDna;
import com.healing.models.ElementContext;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Comparator;
import java.util.Map;
import java.util.stream.Collectors;

public class DomDnaNormalizer {
    public DomDna fromContext(String locatorId, ElementContext context) {
        String pageType = classifyPageType(context.getPageUrl());
        return new DomDna(
            locatorId,
            safe(context.getTagName()).toLowerCase(),
            normalizeText(context.getInnerText()),
            context.getAttributes(),
            safe(context.getParentXPath()),
            context.getSiblingTexts(),
            safe(context.getPageUrl()),
            context.getDomDepth(),
            true,
            pageType
        );
    }

    public String normalizeForEmbedding(DomDna domDna) {
        String attrs = domDna.getAttributes().entrySet().stream()
            .sorted(Comparator.comparing(Map.Entry::getKey))
            .map(e -> normalizeToken(e.getKey()) + "=" + normalizeToken(scrubDynamicValues(e.getValue())))
            .collect(Collectors.joining(";"));
        String siblings = domDna.getSiblings().stream()
            .map(this::normalizeText)
            .limit(5)
            .collect(Collectors.joining("|"));
        return String.join(" ",
            "tag=" + normalizeToken(domDna.getTag()),
            "text=" + hashLong(normalizeText(domDna.getText())),
            "attributes=" + attrs,
            "parent=" + normalizeToken(domDna.getParent()),
            "siblings=" + siblings,
            "page=" + normalizeToken(domDna.getPage()),
            "positionBucket=" + bucketPosition(domDna.getPosition()),
            "visible=" + domDna.isVisible(),
            "pageType=" + normalizeToken(domDna.getPageType())
        );
    }

    private String scrubDynamicValues(String value) {
        return safe(value).replaceAll("([a-f0-9]{8,}|\\d{3,})", "{dyn}");
    }

    private String normalizeText(String text) {
        return safe(text).replaceAll("\\s+", " ").trim().toLowerCase();
    }

    private String normalizeToken(String token) {
        return safe(token).replaceAll("\\s+", "_").toLowerCase();
    }

    private String bucketPosition(int position) {
        if (position <= 2) return "top";
        if (position <= 6) return "mid";
        return "deep";
    }

    private String classifyPageType(String url) {
        String val = safe(url).toLowerCase();
        if (val.contains("login")) return "auth";
        if (val.contains("checkout")) return "checkout";
        if (val.contains("product")) return "catalog";
        return "generic";
    }

    private String hashLong(String value) {
        if (value.length() < 80) {
            return value;
        }
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception ignored) {
            return value.substring(0, 80);
        }
    }

    private String safe(String input) {
        return input == null ? "" : input;
    }
}
