package com.healing.intelligence.infrastructure.vector;

import com.healing.intelligence.domain.HistoricalStats;
import com.healing.intelligence.domain.LocatorCandidate;
import com.healing.intelligence.ports.VectorSearchService;
import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class H2VectorSearchService implements VectorSearchService {
    private static final Logger log = LoggerFactory.getLogger(H2VectorSearchService.class);
    private final String jdbcUrl;
    private final String user;
    private final String password;
    private final String projectId;
    private final String env;

    public H2VectorSearchService(String jdbcUrl, String user, String password, String projectId, String env) {
        this.jdbcUrl = jdbcUrl;
        this.user = user;
        this.password = password;
        this.projectId = projectId;
        this.env = env;
        bootstrap();
    }

    private void bootstrap() {
        String ddl = "CREATE TABLE IF NOT EXISTS locator_embeddings (" +
            "tenant_project VARCHAR(255), tenant_env VARCHAR(255), locator_id VARCHAR(255), embedding_id VARCHAR(255), page VARCHAR(512), page_type VARCHAR(128), " +
            "css VARCHAR(2000), xpath VARCHAR(3000), dim INT, vector_blob BLOB, norm DOUBLE, weight DOUBLE, updated_at TIMESTAMP)";
        try (Connection conn = getConn(); PreparedStatement ps = conn.prepareStatement(ddl)) {
            ps.execute();
            conn.createStatement().execute("CREATE INDEX IF NOT EXISTS idx_embeddings_tenant_page ON locator_embeddings(tenant_project, tenant_env, page, page_type)");
        } catch (Exception e) {
            throw new IllegalStateException("Unable to initialize H2 vector storage", e);
        }
    }

    @Override
    public List<LocatorCandidate> searchTopK(float[] queryEmbedding, String page, String pageType, int k) {
        List<LocatorCandidate> candidates = new ArrayList<>();
        String sql = "SELECT locator_id, css, xpath, vector_blob, weight FROM locator_embeddings " +
            "WHERE tenant_project = ? AND tenant_env = ? AND (page = ? OR page_type = ?)";
        try (Connection conn = getConn(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, projectId);
            ps.setString(2, env);
            ps.setString(3, page);
            ps.setString(4, pageType);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                float[] vector = toFloatArray(rs.getBytes("vector_blob"));
                double sim = CosineSimilarity.score(queryEmbedding, vector);
                double weighted = sim * rs.getDouble("weight");
                String css = rs.getString("css");
                String xpath = rs.getString("xpath");
                By by = toBy(css, xpath, rs.getString("locator_id"));
                if (by == null) {
                    continue;
                }
                candidates.add(new LocatorCandidate(rs.getString("locator_id"), by, "vector", weighted, 0.0d, HistoricalStats.empty()));
            }
        } catch (Exception e) {
            log.warn("Vector search failed: {}", e.getMessage());
        }
        candidates.sort(Comparator.comparingDouble(LocatorCandidate::getEmbeddingSimilarity).reversed());
        return candidates.size() <= k ? candidates : candidates.subList(0, k);
    }

    @Override
    public void upsertEmbedding(String locatorId, String page, String pageType, float[] embedding, double weight) {
        String merge = "MERGE INTO locator_embeddings(tenant_project, tenant_env, locator_id, embedding_id, page, page_type, css, xpath, dim, vector_blob, norm, weight, updated_at) " +
            "KEY(tenant_project, tenant_env, locator_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
        try (Connection conn = getConn(); PreparedStatement ps = conn.prepareStatement(merge)) {
            ps.setString(1, projectId);
            ps.setString(2, env);
            ps.setString(3, locatorId);
            ps.setString(4, locatorId + "-emb");
            ps.setString(5, page);
            ps.setString(6, pageType);
            ps.setString(7, "");
            ps.setString(8, "");
            ps.setInt(9, embedding.length);
            ps.setBytes(10, toBytes(embedding));
            ps.setDouble(11, l2Norm(embedding));
            ps.setDouble(12, weight);
            ps.executeUpdate();
        } catch (Exception e) {
            log.warn("Could not upsert embedding for {}: {}", locatorId, e.getMessage());
        }
    }

    public void upsertEmbeddingWithLocator(String locatorId, String page, String pageType, float[] embedding,
                                           String css, String xpath, double weight) {
        String merge = "MERGE INTO locator_embeddings(tenant_project, tenant_env, locator_id, embedding_id, page, page_type, css, xpath, dim, vector_blob, norm, weight, updated_at) " +
            "KEY(tenant_project, tenant_env, locator_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
        try (Connection conn = getConn(); PreparedStatement ps = conn.prepareStatement(merge)) {
            ps.setString(1, projectId);
            ps.setString(2, env);
            ps.setString(3, locatorId);
            ps.setString(4, locatorId + "-emb");
            ps.setString(5, page);
            ps.setString(6, pageType);
            ps.setString(7, css);
            ps.setString(8, xpath);
            ps.setInt(9, embedding.length);
            ps.setBytes(10, toBytes(embedding));
            ps.setDouble(11, l2Norm(embedding));
            ps.setDouble(12, weight);
            ps.executeUpdate();
        } catch (Exception e) {
            log.warn("Could not upsert embedding for {}: {}", locatorId, e.getMessage());
        }
    }

    private Connection getConn() throws Exception {
        return DriverManager.getConnection(jdbcUrl, user, password);
    }

    private double l2Norm(float[] vector) {
        double sum = 0;
        for (float value : vector) sum += value * value;
        return Math.sqrt(sum);
    }

    private byte[] toBytes(float[] vector) {
        ByteBuffer buffer = ByteBuffer.allocate(vector.length * Float.BYTES);
        for (float val : vector) buffer.putFloat(val);
        return buffer.array();
    }

    private float[] toFloatArray(byte[] bytes) {
        if (bytes == null) return new float[0];
        ByteBuffer buffer = ByteBuffer.wrap(bytes);
        float[] vector = new float[bytes.length / Float.BYTES];
        for (int i = 0; i < vector.length; i++) vector[i] = buffer.getFloat();
        return vector;
    }

    private By toBy(String css, String xpath, String locatorId) {
        try {
            if (css != null && !css.trim().isEmpty()) return By.cssSelector(css.trim());
            if (xpath != null && !xpath.trim().isEmpty()) return By.xpath(xpath.trim());
            if (locatorId != null) {
                if (locatorId.startsWith("id:")) return By.id(locatorId.substring(3));
                if (locatorId.startsWith("name:")) return By.name(locatorId.substring(5));
                if (locatorId.startsWith("css:")) return By.cssSelector(locatorId.substring(4));
                if (locatorId.startsWith("xpath:")) return By.xpath(locatorId.substring(6));
            }
        } catch (Exception e) {
            log.debug("Invalid locator reconstructed from vector row {}: {}", locatorId, e.getMessage());
        }
        return null;
    }
}
