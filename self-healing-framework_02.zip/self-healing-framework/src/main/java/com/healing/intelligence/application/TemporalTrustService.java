package com.healing.intelligence.application;

import com.healing.intelligence.domain.HistoricalStats;

public class TemporalTrustService {
    public double adjustedHistoricalScore(HistoricalStats stats, double buildSpikeScore) {
        double base = stats.successRate();
        double trust = stats.getTrustScore();
        double spikePenalty = Math.min(0.2d, buildSpikeScore * 0.2d);
        return clamp((0.7d * base + 0.3d * trust) - spikePenalty);
    }

    private double clamp(double value) {
        return Math.max(0.0d, Math.min(1.0d, value));
    }
}
