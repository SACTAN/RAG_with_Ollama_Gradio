package com.healing.intelligence.infrastructure.neo4j;

import com.healing.intelligence.domain.HealingSignal;
import com.healing.intelligence.domain.HistoricalStats;
import com.healing.intelligence.domain.LocatorCandidate;
import com.healing.intelligence.ports.GraphService;
import org.neo4j.driver.AuthTokens;
import org.neo4j.driver.Driver;
import org.neo4j.driver.GraphDatabase;
import org.neo4j.driver.Record;
import org.neo4j.driver.Session;
import org.neo4j.driver.Values;
import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class Neo4jGraphService implements GraphService, AutoCloseable {
    private static final Logger log = LoggerFactory.getLogger(Neo4jGraphService.class);
    private final Driver driver;
    private final String projectId;
    private final String env;

    public Neo4jGraphService(String uri, String username, String password, String projectId, String env) {
        this.driver = GraphDatabase.driver(uri, AuthTokens.basic(username, password));
        this.projectId = projectId;
        this.env = env;
    }

    @Override
    public void bootstrapSchema() {
        try (Session session = driver.session()) {
            session.run("CREATE CONSTRAINT locator_tenant_id IF NOT EXISTS FOR (l:Locator) REQUIRE (l.projectId, l.env, l.id) IS UNIQUE");
            session.run("CREATE CONSTRAINT page_name IF NOT EXISTS FOR (p:Page) REQUIRE p.name IS UNIQUE");
            session.run("CREATE CONSTRAINT testcase_name IF NOT EXISTS FOR (t:TestCase) REQUIRE t.name IS UNIQUE");
            session.run("CREATE CONSTRAINT build_version IF NOT EXISTS FOR (b:Build) REQUIRE b.version IS UNIQUE");
            session.run("CREATE INDEX locator_page_text IF NOT EXISTS FOR (l:Locator) ON (l.page, l.text)");
            session.run("CREATE INDEX locator_last_seen IF NOT EXISTS FOR (l:Locator) ON (l.lastSeenAt)");
        }
    }

    @Override
    public List<LocatorCandidate> fetchHealedToCandidates(String locatorId, String page, int limit) {
        String cypher =
            "MATCH (src:Locator {id: $locatorId, projectId:$projectId, env:$env})-[r:HEALED_TO]->(dst:Locator {projectId:$projectId, env:$env})-[:LOCATED_ON]->(:Page {name: $page}) " +
            "RETURN dst.id as id, dst.css as css, dst.xpath as xpath, dst.text as text, " +
            "coalesce(r.confidence, 0.0) as proximity, " +
            "coalesce(dst.successCount,0) as successCount, coalesce(dst.failCount,0) as failCount, " +
            "coalesce(dst.trustScore,0.5) as trustScore ORDER BY proximity DESC LIMIT $limit";
        return runCandidateQuery(cypher, Values.parameters("locatorId", locatorId, "page", page, "limit", limit, "projectId", projectId, "env", env), "graph-healed");
    }

    @Override
    public List<LocatorCandidate> fetchSamePageCandidates(String page, int limit) {
        String cypher =
            "MATCH (dst:Locator {projectId:$projectId, env:$env})-[:LOCATED_ON]->(:Page {name: $page}) " +
            "RETURN dst.id as id, dst.css as css, dst.xpath as xpath, dst.text as text, " +
            "coalesce(dst.trustScore, 0.35) as proximity, " +
            "coalesce(dst.successCount,0) as successCount, coalesce(dst.failCount,0) as failCount, " +
            "coalesce(dst.trustScore,0.5) as trustScore ORDER BY proximity DESC LIMIT $limit";
        return runCandidateQuery(cypher, Values.parameters("page", page, "limit", limit, "projectId", projectId, "env", env), "graph-page");
    }

    @Override
    public double failureSpikeScore(String page, String buildVersion) {
        String cypher =
            "MATCH (:Locator {projectId:$projectId, env:$env})-[f:FAILED_IN]->(b:Build) WHERE b.version = $buildVersion AND f.page = $page " +
            "WITH count(f) as currentCount " +
            "MATCH (:Locator {projectId:$projectId, env:$env})-[f2:FAILED_IN]->(b2:Build) WHERE b2.version <> $buildVersion AND f2.page = $page " +
            "RETURN currentCount, count(f2) as priorCount";
        try (Session session = driver.session()) {
            Record record = session.run(cypher, Values.parameters("page", page, "buildVersion", buildVersion, "projectId", projectId, "env", env)).single();
            double current = record.get("currentCount").asDouble(0.0d);
            double prior = record.get("priorCount").asDouble(0.0d);
            double spike = current / (prior + 1.0d);
            return Math.min(1.0d, spike / 2.0d);
        } catch (Exception e) {
            log.debug("Could not compute failure spike: {}", e.getMessage());
            return 0.0d;
        }
    }

    @Override
    public void recordSuccess(HealingSignal signal) {
        String cypher =
            "MERGE (src:Locator {id:$fromId, projectId:$projectId, env:$env}) " +
            "ON CREATE SET src.css = $fromCss, src.xpath = $fromXpath, src.page = $page, src.createdAt = $ts, src.successCount=0, src.failCount=0, src.trustScore=0.5 " +
            "SET src.lastSeenAt = $ts " +
            "MERGE (dst:Locator {id:$toId, projectId:$projectId, env:$env}) " +
            "ON CREATE SET dst.css = $toCss, dst.xpath = $toXpath, dst.page = $page, dst.createdAt = $ts, dst.successCount=0, dst.failCount=0, dst.trustScore=0.5 " +
            "SET dst.lastSeenAt = $ts, dst.successCount = coalesce(dst.successCount,0) + 1, " +
            "dst.trustScore = CASE WHEN coalesce(dst.trustScore,0.5) + 0.02 > 1.0 THEN 1.0 ELSE coalesce(dst.trustScore,0.5) + 0.02 END " +
            "MERGE (p:Page {name:$page}) SET p.url = $page " +
            "MERGE (src)-[:LOCATED_ON]->(p) MERGE (dst)-[:LOCATED_ON]->(p) " +
            "MERGE (b:Build {version:$buildVersion}) " +
            "MERGE (src)-[h:HEALED_TO]->(dst) " +
            "SET h.timestamp = $ts, h.lastSuccessAt = $ts, h.successCount = coalesce(h.successCount,0) + 1, h.confidence = $confidence";
        try (Session session = driver.session()) {
            session.run(cypher, Values.parameters(
                "fromId", signal.getFromLocatorId(),
                "toId", signal.getToLocatorId(),
                "fromCss", extractCss(signal.getFromLocator()),
                "fromXpath", extractXpath(signal.getFromLocator()),
                "toCss", extractCss(signal.getToLocator()),
                "toXpath", extractXpath(signal.getToLocator()),
                "page", signal.getPage(),
                "buildVersion", signal.getBuildVersion(),
                "confidence", signal.getConfidence(),
                "ts", Instant.now().toString(),
                "projectId", projectId,
                "env", env
            ));
        }
    }

    @Override
    public void recordFailure(String locatorId, String page, String buildVersion, String failureType) {
        String cypher =
            "MERGE (l:Locator {id:$locatorId, projectId:$projectId, env:$env}) " +
            "ON CREATE SET l.page = $page, l.createdAt = $ts, l.successCount=0, l.failCount=0, l.trustScore=0.5 " +
            "SET l.lastSeenAt = $ts, l.failCount = coalesce(l.failCount,0) + 1, " +
            "l.trustScore = CASE WHEN coalesce(l.trustScore,0.5) - 0.03 < 0.0 THEN 0.0 ELSE coalesce(l.trustScore,0.5) - 0.03 END " +
            "MERGE (p:Page {name:$page}) MERGE (l)-[:LOCATED_ON]->(p) " +
            "MERGE (b:Build {version:$buildVersion}) " +
            "CREATE (l)-[:FAILED_IN {timestamp:$ts, page:$page, failureType:$failureType}]->(b)";
        try (Session session = driver.session()) {
            session.run(cypher, Values.parameters(
                "locatorId", locatorId, "page", page, "buildVersion", buildVersion,
                "failureType", failureType, "ts", Instant.now().toString(),
                "projectId", projectId, "env", env));
        }
    }

    @Override
    public void decayLocatorTrust(String page, int staleDays) {
        String staleCutoff = Instant.now().minus(staleDays, ChronoUnit.DAYS).toString();
        String cypher =
            "MATCH (l:Locator {page:$page, projectId:$projectId, env:$env}) WHERE coalesce(l.lastSeenAt, '') < $staleCutoff " +
            "SET l.trustScore = CASE WHEN coalesce(l.trustScore,0.5) * 0.95 < 0.0 THEN 0.0 ELSE coalesce(l.trustScore,0.5) * 0.95 END";
        try (Session session = driver.session()) {
            session.run(cypher, Values.parameters("page", page, "staleCutoff", staleCutoff, "projectId", projectId, "env", env));
        }
    }

    public void upsertLocatorKnowledge(String locatorId, By locator, String page, String testCase, String buildVersion, String text) {
        String cypher =
            "MERGE (l:Locator {id:$locatorId, projectId:$projectId, env:$env}) " +
            "ON CREATE SET l.createdAt = $ts, l.successCount=0, l.failCount=0, l.trustScore=0.5 " +
            "SET l.lastSeenAt = $ts, l.page = $page, l.css = $css, l.xpath = $xpath, l.text = $text " +
            "MERGE (p:Page {name:$page}) SET p.url = $page " +
            "MERGE (l)-[:LOCATED_ON]->(p) " +
            "MERGE (t:TestCase {name:$testCase}) MERGE (l)-[:USED_IN]->(t) " +
            "MERGE (b:Build {version:$buildVersion})";
        try (Session session = driver.session()) {
            session.run(cypher, Values.parameters(
                "locatorId", locatorId,
                "css", extractCss(locator),
                "xpath", extractXpath(locator),
                "text", text == null ? "" : text,
                "page", page,
                "testCase", testCase,
                "buildVersion", buildVersion,
                "ts", Instant.now().toString(),
                "projectId", projectId, "env", env
            ));
        }
    }

    private List<LocatorCandidate> runCandidateQuery(String cypher, org.neo4j.driver.Value params, String source) {
        List<LocatorCandidate> output = new ArrayList<>();
        try (Session session = driver.session()) {
            List<Record> records = session.run(cypher, params).list();
            for (Record record : records) {
                String id = record.get("id").asString("");
                String css = record.get("css").asString("");
                String xpath = record.get("xpath").asString("");
                By by = !css.isEmpty() ? By.cssSelector(css) : By.xpath(xpath);
                HistoricalStats stats = new HistoricalStats(
                    record.get("successCount").asLong(0L),
                    record.get("failCount").asLong(0L),
                    record.get("trustScore").asDouble(0.5d));
                output.add(new LocatorCandidate(id, by, source, 0.0d,
                    record.get("proximity").asDouble(0.0d), stats));
            }
        }
        return output;
    }

    private String extractCss(By by) {
        String value = by == null ? "" : by.toString();
        return value.contains("By.cssSelector:") ? value.replace("By.cssSelector:", "").trim() : "";
    }

    private String extractXpath(By by) {
        String value = by == null ? "" : by.toString();
        return value.contains("By.xpath:") ? value.replace("By.xpath:", "").trim() : "";
    }

    @Override
    public void close() {
        driver.close();
    }
}
