package com.healing.intelligence.ports;

import com.healing.intelligence.domain.LocatorCandidate;
import com.healing.models.ElementContext;

import java.util.List;

public interface HealingEngine {
    List<LocatorCandidate> findBestCandidates(String locatorId, ElementContext context, String buildVersion);
    void learnFromSuccess(String locatorId, LocatorCandidate chosen, ElementContext context, String buildVersion);
    void learnFromFailure(String locatorId, ElementContext context, String buildVersion, String failureType);
}
