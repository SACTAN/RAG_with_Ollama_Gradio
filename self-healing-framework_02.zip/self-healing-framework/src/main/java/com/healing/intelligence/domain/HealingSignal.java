package com.healing.intelligence.domain;

import org.openqa.selenium.By;

public class HealingSignal {
    private final String fromLocatorId;
    private final String toLocatorId;
    private final By fromLocator;
    private final By toLocator;
    private final String page;
    private final String buildVersion;
    private final double confidence;

    public HealingSignal(String fromLocatorId, String toLocatorId, By fromLocator, By toLocator,
                         String page, String buildVersion, double confidence) {
        this.fromLocatorId = fromLocatorId;
        this.toLocatorId = toLocatorId;
        this.fromLocator = fromLocator;
        this.toLocator = toLocator;
        this.page = page;
        this.buildVersion = buildVersion;
        this.confidence = confidence;
    }

    public String getFromLocatorId() { return fromLocatorId; }
    public String getToLocatorId() { return toLocatorId; }
    public By getFromLocator() { return fromLocator; }
    public By getToLocator() { return toLocator; }
    public String getPage() { return page; }
    public String getBuildVersion() { return buildVersion; }
    public double getConfidence() { return confidence; }
}
