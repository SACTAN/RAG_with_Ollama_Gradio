package com.healing.intelligence.infrastructure.embedding;

import com.healing.intelligence.domain.DomDna;
import com.healing.intelligence.ports.EmbeddingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Local embedding service abstraction point.
 * In production, this class can be switched to a full DJL predictor pipeline.
 */
public class DjlEmbeddingService implements EmbeddingService, AutoCloseable {
    private static final Logger log = LoggerFactory.getLogger(DjlEmbeddingService.class);
    private final DomDnaNormalizer normalizer;
    private final String modelName;

    public DjlEmbeddingService(String modelName, DomDnaNormalizer normalizer) {
        this.normalizer = normalizer;
        this.modelName = modelName;
    }

    @Override
    public float[] generateEmbedding(DomDna domDna) {
        String input = normalizer.normalizeForEmbedding(domDna);
        float[] vector = new float[128];
        byte[] bytes = input.getBytes();
        for (int i = 0; i < bytes.length; i++) {
            vector[i % vector.length] += (bytes[i] & 0xff) / 255.0f;
        }
        return vector;
    }

    @Override
    public void close() {
        log.debug("Embedding service closed for model {}", modelName);
    }
}
