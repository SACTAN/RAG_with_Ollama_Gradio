package com.healing.intelligence.domain;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class DomDna {
    private final String locatorId;
    private final String tag;
    private final String text;
    private final Map<String, String> attributes;
    private final String parent;
    private final List<String> siblings;
    private final String page;
    private final int position;
    private final boolean visible;
    private final String pageType;

    public DomDna(String locatorId, String tag, String text, Map<String, String> attributes, String parent,
                  List<String> siblings, String page, int position, boolean visible, String pageType) {
        this.locatorId = locatorId;
        this.tag = tag;
        this.text = text;
        this.attributes = attributes == null ? Collections.emptyMap() : attributes;
        this.parent = parent;
        this.siblings = siblings == null ? Collections.emptyList() : siblings;
        this.page = page;
        this.position = position;
        this.visible = visible;
        this.pageType = pageType;
    }

    public String getLocatorId() { return locatorId; }
    public String getTag() { return tag; }
    public String getText() { return text; }
    public Map<String, String> getAttributes() { return attributes; }
    public String getParent() { return parent; }
    public List<String> getSiblings() { return siblings; }
    public String getPage() { return page; }
    public int getPosition() { return position; }
    public boolean isVisible() { return visible; }
    public String getPageType() { return pageType; }
}
