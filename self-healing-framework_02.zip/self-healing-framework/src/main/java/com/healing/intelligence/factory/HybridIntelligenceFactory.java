package com.healing.intelligence.factory;

import com.healing.config.HealingConfig;
import com.healing.intelligence.application.HybridHealingEngine;
import com.healing.intelligence.application.HybridScoringService;
import com.healing.intelligence.application.TemporalTrustService;
import com.healing.intelligence.infrastructure.embedding.DjlEmbeddingService;
import com.healing.intelligence.infrastructure.embedding.DomDnaNormalizer;
import com.healing.intelligence.infrastructure.neo4j.Neo4jGraphService;
import com.healing.intelligence.infrastructure.vector.H2VectorSearchService;
import com.healing.intelligence.ports.HealingEngine;

public final class HybridIntelligenceFactory {
    private HybridIntelligenceFactory() {}

    public static HealingEngine create(HealingConfig config) {
        DomDnaNormalizer normalizer = new DomDnaNormalizer();
        Neo4jGraphService graphService = new Neo4jGraphService(
            config.getHybridNeo4jUri(), config.getHybridNeo4jUser(), config.getHybridNeo4jPassword(),
            config.getHybridProjectId(), config.getHybridEnv());
        graphService.bootstrapSchema();

        DjlEmbeddingService embeddingService = new DjlEmbeddingService(config.getHybridEmbeddingModel(), normalizer);
        H2VectorSearchService vectorService = new H2VectorSearchService(
            config.getHybridVectorJdbcUrl(), config.getHybridVectorJdbcUser(), config.getHybridVectorJdbcPassword(),
            config.getHybridProjectId(), config.getHybridEnv());
        return new HybridHealingEngine(
            graphService, embeddingService, vectorService, normalizer,
            new TemporalTrustService(), new HybridScoringService(),
            config.getHybridGraphThreshold(), config.getHybridTopK());
    }
}
