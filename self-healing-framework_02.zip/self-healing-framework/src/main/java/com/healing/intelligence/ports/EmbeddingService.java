package com.healing.intelligence.ports;

import com.healing.intelligence.domain.DomDna;

public interface EmbeddingService {
    float[] generateEmbedding(DomDna domDna);
}
