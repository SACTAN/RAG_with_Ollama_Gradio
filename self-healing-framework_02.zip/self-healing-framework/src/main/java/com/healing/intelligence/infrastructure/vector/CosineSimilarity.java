package com.healing.intelligence.infrastructure.vector;

public final class CosineSimilarity {
    private CosineSimilarity() {}

    public static double score(float[] a, float[] b) {
        if (a == null || b == null || a.length == 0 || b.length == 0 || a.length != b.length) return 0.0d;
        double dot = 0.0d;
        double normA = 0.0d;
        double normB = 0.0d;
        for (int i = 0; i < a.length; i++) {
            dot += a[i] * b[i];
            normA += a[i] * a[i];
            normB += b[i] * b[i];
        }
        if (normA == 0 || normB == 0) return 0.0d;
        return dot / (Math.sqrt(normA) * Math.sqrt(normB));
    }
}
