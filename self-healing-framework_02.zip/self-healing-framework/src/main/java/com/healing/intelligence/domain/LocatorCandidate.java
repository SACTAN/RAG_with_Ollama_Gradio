package com.healing.intelligence.domain;

import org.openqa.selenium.By;

public class LocatorCandidate {
    private final String locatorId;
    private final By locator;
    private final String source;
    private final double embeddingSimilarity;
    private final double graphProximity;
    private final HistoricalStats historicalStats;
    private double finalScore;

    public LocatorCandidate(String locatorId, By locator, String source,
                            double embeddingSimilarity, double graphProximity, HistoricalStats historicalStats) {
        this.locatorId = locatorId;
        this.locator = locator;
        this.source = source;
        this.embeddingSimilarity = embeddingSimilarity;
        this.graphProximity = graphProximity;
        this.historicalStats = historicalStats == null ? HistoricalStats.empty() : historicalStats;
    }

    public String getLocatorId() { return locatorId; }
    public By getLocator() { return locator; }
    public String getSource() { return source; }
    public double getEmbeddingSimilarity() { return embeddingSimilarity; }
    public double getGraphProximity() { return graphProximity; }
    public HistoricalStats getHistoricalStats() { return historicalStats; }
    public double getFinalScore() { return finalScore; }
    public void setFinalScore(double finalScore) { this.finalScore = finalScore; }
}
