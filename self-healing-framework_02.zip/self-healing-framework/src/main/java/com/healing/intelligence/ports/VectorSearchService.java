package com.healing.intelligence.ports;

import com.healing.intelligence.domain.LocatorCandidate;

import java.util.List;

public interface VectorSearchService {
    List<LocatorCandidate> searchTopK(float[] queryEmbedding, String page, String pageType, int k);
    void upsertEmbedding(String locatorId, String page, String pageType, float[] embedding, double weight);
}
