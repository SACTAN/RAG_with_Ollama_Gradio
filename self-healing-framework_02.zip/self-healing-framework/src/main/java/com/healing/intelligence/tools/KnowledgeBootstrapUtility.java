package com.healing.intelligence.tools;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.healing.config.HealingConfig;
import com.healing.intelligence.domain.DomDna;
import com.healing.intelligence.infrastructure.embedding.DjlEmbeddingService;
import com.healing.intelligence.infrastructure.embedding.DomDnaNormalizer;
import com.healing.intelligence.infrastructure.neo4j.Neo4jGraphService;
import com.healing.intelligence.infrastructure.vector.H2VectorSearchService;
import com.healing.models.ElementContext;
import com.healing.utils.DriverFactory;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

public class KnowledgeBootstrapUtility {
    private static final Logger log = LoggerFactory.getLogger(KnowledgeBootstrapUtility.class);

    public static void main(String[] args) throws Exception {
        Map<String, String> options = parseArgs(args);
        String mode = options.getOrDefault("mode", "html");
        String page = options.getOrDefault("page", "bootstrap-page");
        String testCase = options.getOrDefault("testCase", "bootstrap-case");
        String build = options.getOrDefault("build", "bootstrap-build");

        HealingConfig config = HealingConfig.getInstance();
        DomDnaNormalizer normalizer = new DomDnaNormalizer();
        try (Neo4jGraphService graph = new Neo4jGraphService(config.getHybridNeo4jUri(),
            config.getHybridNeo4jUser(), config.getHybridNeo4jPassword(),
            config.getHybridProjectId(), config.getHybridEnv());
             DjlEmbeddingService embeddingService = new DjlEmbeddingService(config.getHybridEmbeddingModel(), normalizer)) {

            graph.bootstrapSchema();
            H2VectorSearchService vector = new H2VectorSearchService(config.getHybridVectorJdbcUrl(),
                config.getHybridVectorJdbcUser(), config.getHybridVectorJdbcPassword(),
                config.getHybridProjectId(), config.getHybridEnv());

            List<SeedRecord> records;
            switch (mode.toLowerCase()) {
                case "crawl":
                    records = loadFromCrawlSnapshots(Path.of(require(options, "input")), page);
                    break;
                case "json":
                    records = loadFromJson(Path.of(require(options, "input")));
                    break;
                case "runtime":
                    records = loadFromRuntime(require(options, "url"), page);
                    break;
                case "html":
                default:
                    records = loadFromHtml(Path.of(require(options, "input")), page);
                    break;
            }

            int trained = 0;
            for (SeedRecord record : records) {
                if (record.locator == null) continue;
                graph.upsertLocatorKnowledge(record.locatorId, record.locator, record.page, testCase, build, record.text);
                ElementContext context = toContext(record);
                DomDna domDna = normalizer.fromContext(record.locatorId, context);
                float[] embedding = embeddingService.generateEmbedding(domDna);
                vector.upsertEmbeddingWithLocator(record.locatorId, record.page, domDna.getPageType(),
                    embedding, extractCss(record.locator), extractXpath(record.locator), 1.0d);
                trained++;
            }
            log.info("Knowledge bootstrap complete. Trained {} locator records.", trained);
        }
    }

    private static List<SeedRecord> loadFromHtml(Path htmlFile, String page) throws IOException {
        Document doc = Jsoup.parse(Files.readString(htmlFile));
        List<SeedRecord> records = new ArrayList<>();
        for (Element el : doc.select("button,input,a,select,textarea,[data-testid],[aria-label],[id],[name]")) {
            String locatorId = deriveLocatorId(el);
            By by = deriveLocator(el);
            if (by == null) continue;
            records.add(new SeedRecord(locatorId, by, page, el.text(), toAttributes(el), el.tagName()));
        }
        return deduplicate(records);
    }

    private static List<SeedRecord> loadFromRuntime(String url, String page) {
        try {
            com.healing.core.SelfHealingWebDriver shDriver = DriverFactory.createChromeDriver(true);
            WebDriver driver = shDriver.getDelegate();
            driver.get(url);
            String source = driver.getPageSource();
            Path temp = Files.createTempFile("runtime-page-", ".html");
            Files.writeString(temp, source);
            List<SeedRecord> records = loadFromHtml(temp, page);
            Files.deleteIfExists(temp);
            shDriver.quit();
            return records;
        } catch (Exception e) {
            throw new IllegalStateException("Runtime capture failed for URL: " + url, e);
        }
    }

    private static List<SeedRecord> loadFromCrawlSnapshots(Path snapshotRoot, String defaultPage) throws IOException {
        List<SeedRecord> combined = new ArrayList<>();
        List<Path> files = Files.walk(snapshotRoot)
            .filter(path -> Files.isRegularFile(path) && (path.toString().endsWith(".html") || path.toString().endsWith(".htm")))
            .collect(Collectors.toList());
        for (Path file : files) {
            String page = defaultPage.equals("bootstrap-page") ? file.toString() : defaultPage;
            combined.addAll(loadFromHtml(file, page));
        }
        return deduplicate(combined);
    }

    private static List<SeedRecord> loadFromJson(Path jsonFile) throws IOException {
        String json = Files.readString(jsonFile);
        Type type = new TypeToken<List<SeedJson>>() {}.getType();
        List<SeedJson> seeds = new Gson().fromJson(json, type);
        List<SeedRecord> records = new ArrayList<>();
        for (SeedJson seed : seeds) {
            By by = toBy(seed);
            if (by == null) continue;
            records.add(new SeedRecord(seed.locatorId, by, defaultIfEmpty(seed.page, "json-page"),
                defaultIfEmpty(seed.text, ""), seed.attributes == null ? Collections.emptyMap() : seed.attributes,
                defaultIfEmpty(seed.tag, "div")));
        }
        return deduplicate(records);
    }

    private static ElementContext toContext(SeedRecord record) {
        return new ElementContext(record.locator)
            .withPageUrl(record.page)
            .withTagName(record.tag)
            .withInnerText(record.text)
            .withAttributes(record.attributes)
            .withDomDepth(3);
    }

    private static By deriveLocator(Element el) {
        String id = el.id();
        if (!id.isEmpty()) return By.id(id);
        String dataTestId = el.attr("data-testid");
        if (!dataTestId.isEmpty()) return By.cssSelector("[data-testid='" + escape(dataTestId) + "']");
        String name = el.attr("name");
        if (!name.isEmpty()) return By.name(name);
        String aria = el.attr("aria-label");
        if (!aria.isEmpty()) return By.cssSelector("[aria-label='" + escape(aria) + "']");
        String css = el.cssSelector();
        if (!css.isEmpty()) return By.cssSelector(css);
        return null;
    }

    private static String deriveLocatorId(Element el) {
        if (!el.id().isEmpty()) return "id:" + el.id();
        if (!el.attr("name").isEmpty()) return "name:" + el.attr("name");
        if (!el.attr("data-testid").isEmpty()) return "css:[data-testid='" + el.attr("data-testid") + "']";
        return "css:" + el.cssSelector();
    }

    private static Map<String, String> toAttributes(Element el) {
        Map<String, String> attrs = new LinkedHashMap<>();
        el.attributes().forEach(a -> attrs.put(a.getKey(), a.getValue()));
        return attrs;
    }

    private static By toBy(SeedJson seed) {
        if (!isEmpty(seed.css)) return By.cssSelector(seed.css);
        if (!isEmpty(seed.xpath)) return By.xpath(seed.xpath);
        if (!isEmpty(seed.id)) return By.id(seed.id);
        if (!isEmpty(seed.name)) return By.name(seed.name);
        return null;
    }

    private static List<SeedRecord> deduplicate(List<SeedRecord> records) {
        Map<String, SeedRecord> dedup = new LinkedHashMap<>();
        for (SeedRecord record : records) {
            dedup.putIfAbsent(record.locatorId + "|" + record.locator.toString(), record);
        }
        return new ArrayList<>(dedup.values());
    }

    private static String extractCss(By by) {
        String value = by == null ? "" : by.toString();
        if (value.contains("By.cssSelector:")) return value.replace("By.cssSelector:", "").trim();
        if (value.contains("By.id:")) return "#" + value.replace("By.id:", "").trim();
        if (value.contains("By.name:")) return "[name='" + value.replace("By.name:", "").trim() + "']";
        return "";
    }

    private static String extractXpath(By by) {
        String value = by == null ? "" : by.toString();
        if (value.contains("By.xpath:")) return value.replace("By.xpath:", "").trim();
        if (value.contains("By.id:")) return "//*[@id='" + value.replace("By.id:", "").trim() + "']";
        if (value.contains("By.name:")) return "//*[@name='" + value.replace("By.name:", "").trim() + "']";
        return "";
    }

    private static Map<String, String> parseArgs(String[] args) {
        Map<String, String> map = new HashMap<>();
        for (String arg : args) {
            if (!arg.startsWith("--") || !arg.contains("=")) continue;
            String[] parts = arg.substring(2).split("=", 2);
            map.put(parts[0], parts[1]);
        }
        return map;
    }

    private static String require(Map<String, String> options, String key) {
        String value = options.get(key);
        if (isEmpty(value)) throw new IllegalArgumentException("Missing required argument: --" + key + "=...");
        return value;
    }

    private static String defaultIfEmpty(String value, String fallback) {
        return isEmpty(value) ? fallback : value;
    }

    private static boolean isEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    private static String escape(String value) {
        return value.replace("\\", "\\\\").replace("'", "\\'");
    }

    private static final class SeedJson {
        String locatorId;
        String id;
        String name;
        String css;
        String xpath;
        String page;
        String text;
        String tag;
        Map<String, String> attributes;
    }

    private static final class SeedRecord {
        final String locatorId;
        final By locator;
        final String page;
        final String text;
        final Map<String, String> attributes;
        final String tag;

        private SeedRecord(String locatorId, By locator, String page, String text, Map<String, String> attributes, String tag) {
            this.locatorId = locatorId;
            this.locator = locator;
            this.page = page;
            this.text = text;
            this.attributes = attributes;
            this.tag = tag;
        }
    }
}
