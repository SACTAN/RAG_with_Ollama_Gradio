package com.healing.intelligence.ports;

import com.healing.intelligence.domain.HealingSignal;
import com.healing.intelligence.domain.LocatorCandidate;

import java.util.List;

public interface GraphService {
    void bootstrapSchema();
    List<LocatorCandidate> fetchHealedToCandidates(String locatorId, String page, int limit);
    List<LocatorCandidate> fetchSamePageCandidates(String page, int limit);
    double failureSpikeScore(String page, String buildVersion);
    void recordSuccess(HealingSignal signal);
    void recordFailure(String locatorId, String page, String buildVersion, String failureType);
    void decayLocatorTrust(String page, int staleDays);
}
