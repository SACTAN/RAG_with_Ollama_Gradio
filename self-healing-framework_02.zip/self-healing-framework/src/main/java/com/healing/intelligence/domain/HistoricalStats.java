package com.healing.intelligence.domain;

public class HistoricalStats {
    private final long successCount;
    private final long failureCount;
    private final double trustScore;

    public HistoricalStats(long successCount, long failureCount, double trustScore) {
        this.successCount = successCount;
        this.failureCount = failureCount;
        this.trustScore = trustScore;
    }

    public static HistoricalStats empty() {
        return new HistoricalStats(0, 0, 0.5d);
    }

    public long getSuccessCount() { return successCount; }
    public long getFailureCount() { return failureCount; }
    public double getTrustScore() { return trustScore; }

    public double successRate() {
        long total = successCount + failureCount;
        return total == 0 ? 0.5d : (double) successCount / total;
    }
}
