package com.healing.intelligence.application;

import com.healing.intelligence.domain.LocatorCandidate;

public class HybridScoringService {
    public double score(LocatorCandidate candidate, double adjustedHistorical) {
        return (0.6d * candidate.getEmbeddingSimilarity())
            + (0.3d * candidate.getGraphProximity())
            + (0.1d * adjustedHistorical);
    }
}
