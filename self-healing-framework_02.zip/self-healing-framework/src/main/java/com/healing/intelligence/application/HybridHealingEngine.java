package com.healing.intelligence.application;

import com.healing.intelligence.domain.DomDna;
import com.healing.intelligence.domain.HealingSignal;
import com.healing.intelligence.domain.LocatorCandidate;
import com.healing.intelligence.infrastructure.embedding.DomDnaNormalizer;
import com.healing.intelligence.infrastructure.vector.H2VectorSearchService;
import com.healing.intelligence.ports.EmbeddingService;
import com.healing.intelligence.ports.GraphService;
import com.healing.intelligence.ports.HealingEngine;
import com.healing.intelligence.ports.VectorSearchService;
import com.healing.models.ElementContext;
import org.openqa.selenium.By;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class HybridHealingEngine implements HealingEngine {
    private final GraphService graphService;
    private final EmbeddingService embeddingService;
    private final VectorSearchService vectorSearchService;
    private final DomDnaNormalizer normalizer;
    private final TemporalTrustService temporalTrustService;
    private final HybridScoringService scoringService;
    private final double graphConfidenceThreshold;
    private final int topK;
    private final ExecutorService retrievalExecutor = Executors.newFixedThreadPool(2);

    public HybridHealingEngine(GraphService graphService, EmbeddingService embeddingService,
                               VectorSearchService vectorSearchService, DomDnaNormalizer normalizer,
                               TemporalTrustService temporalTrustService, HybridScoringService scoringService,
                               double graphConfidenceThreshold, int topK) {
        this.graphService = graphService;
        this.embeddingService = embeddingService;
        this.vectorSearchService = vectorSearchService;
        this.normalizer = normalizer;
        this.temporalTrustService = temporalTrustService;
        this.scoringService = scoringService;
        this.graphConfidenceThreshold = graphConfidenceThreshold;
        this.topK = topK;
    }

    @Override
    public List<LocatorCandidate> findBestCandidates(String locatorId, ElementContext context, String buildVersion) {
        String page = context.getPageUrl() == null ? "unknown-page" : context.getPageUrl();
        DomDna domDna = normalizer.fromContext(locatorId, context);
        float[] embedding = embeddingService.generateEmbedding(domDna);

        CompletableFuture<List<LocatorCandidate>> healedFuture = CompletableFuture.supplyAsync(
            () -> graphService.fetchHealedToCandidates(locatorId, page, topK), retrievalExecutor);
        CompletableFuture<List<LocatorCandidate>> samePageFuture = CompletableFuture.supplyAsync(
            () -> graphService.fetchSamePageCandidates(page, topK), retrievalExecutor);
        CompletableFuture<List<LocatorCandidate>> vectorFuture = CompletableFuture.supplyAsync(
            () -> vectorSearchService.searchTopK(embedding, page, domDna.getPageType(), topK), retrievalExecutor);

        List<LocatorCandidate> graphCandidates = new ArrayList<>(awaitCandidates(healedFuture));
        graphCandidates.addAll(awaitCandidates(samePageFuture));
        graphCandidates.addAll(buildBootstrapCandidates(locatorId, context));
        double topGraph = graphCandidates.stream().mapToDouble(LocatorCandidate::getGraphProximity).max().orElse(0.0d);

        List<LocatorCandidate> embeddingCandidates = topGraph >= graphConfidenceThreshold
            ? new ArrayList<>()
            : awaitCandidates(vectorFuture);

        Map<String, LocatorCandidate> merged = new LinkedHashMap<>();
        for (LocatorCandidate candidate : graphCandidates) merged.put(candidate.getLocatorId(), candidate);
        for (LocatorCandidate candidate : embeddingCandidates) {
            merged.merge(candidate.getLocatorId(), candidate, (left, right) ->
                new LocatorCandidate(left.getLocatorId(), pickLocator(left.getLocator(), right.getLocator()),
                    "hybrid", right.getEmbeddingSimilarity(), left.getGraphProximity(), left.getHistoricalStats()));
        }

        double spikeScore = graphService.failureSpikeScore(page, buildVersion);
        List<LocatorCandidate> ranked = new ArrayList<>(merged.values());
        for (LocatorCandidate candidate : ranked) {
            double historical = temporalTrustService.adjustedHistoricalScore(candidate.getHistoricalStats(), spikeScore);
            candidate.setFinalScore(scoringService.score(candidate, historical));
        }
        ranked.sort(Comparator.comparingDouble(LocatorCandidate::getFinalScore).reversed());
        return ranked;
    }

    @Override
    public void learnFromSuccess(String locatorId, LocatorCandidate chosen, ElementContext context, String buildVersion) {
        String page = context.getPageUrl() == null ? "unknown-page" : context.getPageUrl();
        DomDna domDna = normalizer.fromContext(chosen.getLocatorId(), context);
        float[] emb = embeddingService.generateEmbedding(domDna);
        graphService.recordSuccess(new HealingSignal(locatorId, chosen.getLocatorId(), context.getOriginalLocator(),
            chosen.getLocator(), page, buildVersion, chosen.getFinalScore()));
        vectorSearchService.upsertEmbedding(chosen.getLocatorId(), page, domDna.getPageType(), emb, 1.0d + chosen.getFinalScore());
        if (vectorSearchService instanceof H2VectorSearchService) {
            H2VectorSearchService h2 = (H2VectorSearchService) vectorSearchService;
            h2.upsertEmbeddingWithLocator(chosen.getLocatorId(), page, domDna.getPageType(), emb,
                bestCss(chosen), bestXpath(chosen), 1.0d + chosen.getFinalScore());
        }
    }

    @Override
    public void learnFromFailure(String locatorId, ElementContext context, String buildVersion, String failureType) {
        String page = context.getPageUrl() == null ? "unknown-page" : context.getPageUrl();
        graphService.recordFailure(locatorId, page, buildVersion, failureType);
        graphService.decayLocatorTrust(page, 30);
    }

    private By pickLocator(By left, By right) {
        return left != null ? left : right;
    }

    private String extractCss(By by) {
        if (by == null) return "";
        String value = by.toString();
        return value.contains("By.cssSelector:") ? value.replace("By.cssSelector:", "").trim() : "";
    }

    private String extractXpath(By by) {
        if (by == null) return "";
        String value = by.toString();
        return value.contains("By.xpath:") ? value.replace("By.xpath:", "").trim() : "";
    }

    private List<LocatorCandidate> buildBootstrapCandidates(String locatorId, ElementContext context) {
        List<LocatorCandidate> candidates = new ArrayList<>();
        String locatorType = context.getLocatorType();
        String locatorValue = context.getLocatorValue();
        if (locatorValue == null || locatorValue.trim().isEmpty()) {
            return candidates;
        }
        String value = locatorValue.trim();

        addCandidate(candidates, locatorId + "#id", By.id(value), 0.0d, 0.55d, "bootstrap-id");
        addCandidate(candidates, locatorId + "#name", By.name(value), 0.0d, 0.50d, "bootstrap-name");
        addCandidate(candidates, locatorId + "#data-testid", By.cssSelector("[data-testid='" + cssEscape(value) + "']"), 0.0d, 0.48d, "bootstrap-testid");
        addCandidate(candidates, locatorId + "#aria-label", By.cssSelector("[aria-label='" + cssEscape(value) + "']"), 0.0d, 0.46d, "bootstrap-aria");
        addCandidate(candidates, locatorId + "#id-contains", By.cssSelector("[id*='" + cssEscape(value) + "']"), 0.0d, 0.44d, "bootstrap-id-contains");

        if ("css".equals(locatorType)) {
            addCandidate(candidates, locatorId + "#css", By.cssSelector(value), 0.0d, 0.58d, "bootstrap-css-original");
        } else if ("xpath".equals(locatorType)) {
            addCandidate(candidates, locatorId + "#xpath", By.xpath(value), 0.0d, 0.58d, "bootstrap-xpath-original");
            String idFromXpath = extractXpathAttr(value, "id");
            if (!idFromXpath.isEmpty()) {
                addCandidate(candidates, locatorId + "#xpath-id", By.id(idFromXpath), 0.0d, 0.60d, "bootstrap-xpath-id");
            }
        }

        if (context.getTagName() != null && !context.getTagName().isEmpty()) {
            String tag = context.getTagName().toLowerCase();
            addCandidate(candidates, locatorId + "#tag-role", By.cssSelector(tag + "[role]"), 0.0d, 0.30d, "bootstrap-tag-role");
        }
        return candidates;
    }

    private void addCandidate(List<LocatorCandidate> candidates, String id, By by, double emb, double graph, String source) {
        if (by == null) return;
        if (candidates.stream().anyMatch(c -> Objects.equals(c.getLocator().toString(), by.toString()))) return;
        candidates.add(new LocatorCandidate(id, by, source, emb, graph, com.healing.intelligence.domain.HistoricalStats.empty()));
    }

    private String bestCss(LocatorCandidate candidate) {
        String css = extractCss(candidate.getLocator());
        if (!css.isEmpty()) return css;
        String descriptor = candidate.getLocator() == null ? "" : candidate.getLocator().toString();
        if (descriptor.startsWith("By.id:")) {
            String id = descriptor.replace("By.id:", "").trim();
            return "#" + id;
        }
        if (descriptor.startsWith("By.name:")) {
            String name = descriptor.replace("By.name:", "").trim();
            return "[name='" + cssEscape(name) + "']";
        }
        return "";
    }

    private String bestXpath(LocatorCandidate candidate) {
        String xpath = extractXpath(candidate.getLocator());
        if (!xpath.isEmpty()) return xpath;
        String descriptor = candidate.getLocator() == null ? "" : candidate.getLocator().toString();
        if (descriptor.startsWith("By.id:")) {
            String id = descriptor.replace("By.id:", "").trim();
            return "//*[@id='" + id + "']";
        }
        if (descriptor.startsWith("By.name:")) {
            String name = descriptor.replace("By.name:", "").trim();
            return "//*[@name='" + name + "']";
        }
        return "";
    }

    private String extractXpathAttr(String xpath, String attribute) {
        String pattern = "@" + attribute + "='";
        int start = xpath.indexOf(pattern);
        if (start < 0) return "";
        start += pattern.length();
        int end = xpath.indexOf("'", start);
        if (end < 0) return "";
        return xpath.substring(start, end);
    }

    private String cssEscape(String text) {
        return text.replace("\\", "\\\\").replace("'", "\\'");
    }

    private List<LocatorCandidate> awaitCandidates(CompletableFuture<List<LocatorCandidate>> future) {
        try {
            return future.get(3, TimeUnit.SECONDS);
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}
