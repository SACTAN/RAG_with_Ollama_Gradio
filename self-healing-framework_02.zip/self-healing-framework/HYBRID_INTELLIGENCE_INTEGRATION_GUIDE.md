# Hybrid Intelligence Integration Guide

This file is a practical runbook for teams integrating this implementation into an existing Selenium + Java framework.

## 1) Integration Objective
Integrate a Hybrid self-healing layer that combines:
- graph intelligence (Neo4j)
- semantic retrieval (H2 vector embedding store)
- runtime self-learning after success/failure

without breaking existing Selenium flows.

## 2) Minimum Stack Requirements
- Java 11 (build is configured with compiler `release=11`)
- Maven 3.8+
- Selenium 4
- Neo4j 5.x (Bolt enabled)
- Chrome/Firefox/Edge driver runtime as applicable

## 3) What To Copy Into Your Project

### Core Hybrid Packages
- `com.healing.intelligence.domain`
- `com.healing.intelligence.ports`
- `com.healing.intelligence.application`
- `com.healing.intelligence.infrastructure.neo4j`
- `com.healing.intelligence.infrastructure.embedding`
- `com.healing.intelligence.infrastructure.vector`
- `com.healing.intelligence.factory`
- `com.healing.intelligence.tools` (training/bootstrap utility)

### Wiring Layer
- `com.healing.layers.HybridIntelligenceHealingLayer`

### Coordinator / Driver Integration
- `com.healing.core.HybridHealingCoordinator`
- `com.healing.core.SelfHealingWebDriver`

### Config
- `com.healing.config.HealingConfig`
- `src/main/resources/healing-config.properties`

## 4) Required Maven Dependencies
Ensure these exist:
- `org.neo4j.driver:neo4j-java-driver`
- `com.h2database:h2`
- `org.jsoup:jsoup` (for HTML bootstrap utility)
- Selenium/TestNG/SLF4J stack as already used

## 5) Exact Config Keys
Use these keys in `healing-config.properties`:

```properties
healing.enabled=true

healing.layer1.enabled=true
healing.layer2.enabled=true
healing.layer3.enabled=true
healing.layer4.enabled=true

healing.hybrid.enabled=true
healing.hybrid.build.version=local
healing.hybrid.retry.count=3
healing.hybrid.vector.topk=10
healing.hybrid.graph.threshold=0.70

healing.hybrid.neo4j.uri=bolt://localhost:7687
healing.hybrid.neo4j.user=neo4j
healing.hybrid.neo4j.password=password

healing.hybrid.embedding.model=sentence-transformers/all-MiniLM-L6-v2
healing.hybrid.vector.jdbc.url=jdbc:h2:mem:healing_vectors;DB_CLOSE_DELAY=-1
healing.hybrid.vector.jdbc.user=sa
healing.hybrid.vector.jdbc.password=
```

## 6) Runtime Processing Flow
1. Original locator fails in Selenium.
2. `HybridIntelligenceHealingLayer` executes.
3. `HybridHealingEngine` collects:
   - graph `HEALED_TO` candidates
   - graph same-page candidates
   - bootstrap candidates from failing context (id/name/data-testid/aria/css/xpath)
4. If graph confidence low, vector top-K retrieval runs.
5. Candidate pools merged and ranked.
6. Each candidate retried in order (bounded by retry count).
7. Success writes back to graph + vector store.
8. Failure increments failure signals + decay.

## 7) Hybrid Scoring Formula
`finalScore = 0.6*embeddingSimilarity + 0.3*graphProximity + 0.1*historicalSuccessRate`

with temporal/build adjustment from `TemporalTrustService`.

## 8) Selenium Integration Pattern

### Existing tests continue working
```java
SelfHealingWebDriver driver = SelfHealingWebDriver.wrap(new ChromeDriver());
driver.findElement(By.id("login-btn"));
```

### Optional semantic locator id API
```java
driver.registerSmartLocator("checkout.placeOrder", By.cssSelector("button[data-testid='place-order']"));
driver.findElementSmart("checkout.placeOrder");
```

## 9) Neo4j Setup

### Docker quick setup
```powershell
docker run -d --name neo4j-local -p 7474:7474 -p 7687:7687 -e NEO4J_AUTH=neo4j/password neo4j:5
```

Verify:
- HTTP UI: `http://localhost:7474`
- Bolt: `bolt://localhost:7687`

Schema is auto-bootstrapped by `Neo4jGraphService.bootstrapSchema()`.

## 10) Data Training / Bootstrap (important for isolation performance)
Use utility: `com.healing.intelligence.tools.KnowledgeBootstrapUtility`.

### Compile classpath once
```powershell
mvn -q -DskipTests test-compile dependency:build-classpath "-Dmdep.outputFile=target/classpath.txt"
```

### Train from HTML file
```powershell
$cp = Get-Content "target/classpath.txt"
java -cp "target/test-classes;target/classes;$cp" com.healing.intelligence.tools.KnowledgeBootstrapUtility --mode=html --input=sample-page.html --page=https://app/page --testCase=bootstrap-html --build=boot-1
```

### Train from JSON locator file
```powershell
$cp = Get-Content "target/classpath.txt"
java -cp "target/test-classes;target/classes;$cp" com.healing.intelligence.tools.KnowledgeBootstrapUtility --mode=json --input=locators.json --testCase=bootstrap-json --build=boot-1
```

### Train from runtime URL (`getPageSource()`)
```powershell
$cp = Get-Content "target/classpath.txt"
java -cp "target/test-classes;target/classes;$cp" com.healing.intelligence.tools.KnowledgeBootstrapUtility --mode=runtime --url=https://app/login --page=https://app/login --testCase=bootstrap-runtime --build=boot-1
```

## 11) Validation Checklist
- `mvn -q -DskipTests "-Dmaven.compiler.release=11" compile`
- run focused hybrid tests
- run `SelfHealingDemoTest`
- verify reports generated in `target/healing-reports`
- verify Neo4j nodes/relationships are being written
- verify H2 `locator_embeddings` grows after heal success

## 12) Production Rollout Strategy
- Enable hybrid in non-prod first.
- Keep old layers enabled initially for safety.
- Track:
  - success rate
  - mean heal latency
  - false positive rate
  - fallback rate to later layers
- Tune:
  - graph threshold
  - top-K
  - retry budget
- Then gradually increase hybrid reliance.

## 13) Common Integration Pitfalls
- Wrong `neo4j.uri` value (must be proper `bolt://...`, not username).
- Neo4j auth mismatch (causes setup skip/fail).
- Sparse graph/vector knowledge when testing Layer 5 in isolation.
- No bootstrap data before expecting high isolation performance.

## 14) Recommended Integration Sequence For External Teams
1. Integrate packages + dependencies.
2. Configure Neo4j + H2 settings.
3. Wire layer into coordinator.
4. Run baseline suite with all layers enabled.
5. Bootstrap knowledge from HTML/JSON/runtime.
6. Re-run failure-focused tests.
7. Optionally evaluate Layer 5-only behavior.
8. Roll to CI with telemetry.
